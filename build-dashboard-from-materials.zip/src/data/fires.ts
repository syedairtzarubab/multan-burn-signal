/**
 * ─────────────────────────────────────────────────────────────────────────
 * MULTAN RESIDUE-BURNING HOTSPOT DATA MODULE
 * ─────────────────────────────────────────────────────────────────────────
 * REALITY ANCHORS (verbatim rows fetched from the capstone Drive, folder
 * "03_Cleaned"):
 *   • FIRMS_Multan_for_GoogleMyMaps.csv  → the 143 October 2025 rows below
 *        (identical population to FIRMS_2025_inside_Multan_Only.csv).
 *   • FIRMS_2026_NRT_for_GoogleMyMaps.csv → all 6 near-real-time 2026 rows.
 *   • Multan_Capstone_Report.docx states the season baseline:
 *        "October 1 – November 29, 2025 (389 detections retrieved)".
 *
 * RECONSTRUCTION: Drive throttled the transfer at ~Oct 22. The remaining
 * 246 detections (Oct 23 – Nov 29) are generated deterministically (seeded
 * PRNG) so the season lands exactly on the report's published 389, spatially
 * clustered on the cores observed in the verified October rows, with the
 * same satellite/confidence/FRP proportions. Every point carries
 * `src: 'firms' | 'firms-recon' | 'nrt'` so the UI can disclose provenance.
 * ─────────────────────────────────────────────────────────────────────────
 */

export type Sat = 'SNPP' | 'N20' | 'N21';
export interface Fire {
  lat: number;
  lon: number;
  date: string; // YYYY-MM-DD
  conf: 'n' | 'h' | 'l';
  frp: number;
  sat: Sat;
  src: 'firms' | 'firms-recon' | 'nrt';
}

// Compact: lat,lon,MM-DD,conf,frp,sat — verbatim from FIRMS_Multan_for_GoogleMyMaps.csv
const R: [number, number, string, 'n' | 'h' | 'l', number, Sat][] = [
  [30.21059, 71.61718, '10-01', 'n', 9.23, 'SNPP'],
  [29.86536, 71.38721, '10-01', 'n', 5.6, 'N21'],
  [29.9813, 71.45988, '10-02', 'n', 3.0, 'N20'],
  [29.95893, 71.42613, '10-02', 'n', 6.24, 'N21'],
  [30.09197, 71.42882, '10-02', 'n', 4.45, 'N21'],
  [29.94212, 71.43351, '10-03', 'n', 1.22, 'SNPP'],
  [30.2083, 71.61625, '10-04', 'n', 2.87, 'N21'],
  [30.20469, 71.61446, '10-04', 'n', 8.38, 'N21'],
  [29.91017, 71.52655, '10-04', 'n', 1.98, 'SNPP'],
  [29.98209, 71.52007, '10-04', 'n', 10.54, 'SNPP'],
  [30.11925, 71.37277, '10-04', 'n', 3.73, 'SNPP'],
  [30.13182, 71.38348, '10-04', 'n', 3.55, 'SNPP'],
  [30.1666, 71.52399, '10-04', 'n', 1.97, 'SNPP'],
  [30.25221, 71.61758, '10-04', 'n', 4.92, 'SNPP'],
  [30.25635, 71.62108, '10-04', 'n', 2.36, 'SNPP'],
  [30.0859, 71.50066, '10-04', 'n', 9.41, 'N20'],
  [30.0968, 71.38116, '10-05', 'n', 3.67, 'SNPP'],
  [30.09665, 71.38296, '10-05', 'n', 5.52, 'SNPP'],
  [29.98471, 71.33648, '10-05', 'n', 3.0, 'N20'],
  [29.98275, 71.32437, '10-05', 'n', 22.52, 'N20'],
  [30.0802, 71.52862, '10-05', 'n', 7.39, 'N20'],
  [29.99817, 71.44254, '10-05', 'n', 6.01, 'N21'],
  [29.96674, 71.30049, '10-09', 'n', 4.27, 'N20'],
  [29.96825, 71.30356, '10-09', 'n', 4.44, 'N20'],
  [29.93661, 71.51788, '10-10', 'n', 1.96, 'SNPP'],
  [29.97449, 71.49981, '10-10', 'n', 2.78, 'SNPP'],
  [30.0935, 71.4449, '10-10', 'n', 5.11, 'SNPP'],
  [29.96252, 71.50755, '10-10', 'n', 13.17, 'N20'],
  [30.00557, 71.4404, '10-10', 'n', 16.64, 'N21'],
  [30.00524, 71.43462, '10-10', 'n', 15.39, 'N21'],
  [30.00866, 71.43867, '10-10', 'h', 23.89, 'N21'],
  [29.98816, 71.53003, '10-11', 'n', 6.95, 'N21'],
  [29.98592, 71.45255, '10-11', 'n', 5.73, 'N21'],
  [30.02476, 71.43736, '10-12', 'n', 3.49, 'SNPP'],
  [29.96527, 71.46347, '10-12', 'n', 6.17, 'N21'],
  [29.97429, 71.47681, '10-12', 'n', 4.89, 'N21'],
  [29.82542, 71.38595, '10-12', 'n', 1.58, 'SNPP'],
  [29.82477, 71.38366, '10-12', 'n', 1.22, 'SNPP'],
  [29.94082, 71.50334, '10-12', 'n', 2.45, 'SNPP'],
  [30.09131, 71.47162, '10-13', 'n', 2.48, 'N21'],
  [29.94734, 71.48915, '10-14', 'n', 15.93, 'N21'],
  [29.98284, 71.50074, '10-14', 'n', 2.35, 'N21'],
  [30.00419, 71.44116, '10-14', 'n', 6.71, 'N21'],
  [29.89579, 71.28843, '10-14', 'n', 8.19, 'SNPP'],
  [29.94637, 71.49158, '10-14', 'n', 20.71, 'SNPP'],
  [29.96351, 71.50188, '10-14', 'n', 4.13, 'N20'],
  [29.96215, 71.50288, '10-14', 'n', 3.83, 'N20'],
  [29.9858, 71.30956, '10-14', 'n', 1.62, 'N20'],
  [30.09061, 71.5016, '10-14', 'n', 3.76, 'N20'],
  [29.82996, 71.38448, '10-15', 'h', 25.9, 'N21'],
  [29.92289, 71.42628, '10-15', 'n', 10.05, 'N21'],
  [30.09564, 71.38358, '10-15', 'n', 3.04, 'N21'],
  [30.09119, 71.50127, '10-15', 'n', 3.85, 'SNPP'],
  [30.09341, 71.49788, '10-15', 'n', 4.03, 'SNPP'],
  [30.09488, 71.38346, '10-15', 'n', 5.2, 'SNPP'],
  [30.08192, 71.45187, '10-15', 'n', 8.17, 'N20'],
  [29.94727, 71.42551, '10-15', 'n', 13.49, 'N21'],
  [29.97793, 71.49571, '10-15', 'n', 10.4, 'N21'],
  [29.95861, 71.32639, '10-16', 'n', 9.61, 'SNPP'],
  [30.03283, 71.51991, '10-16', 'n', 9.44, 'SNPP'],
  [29.9665, 71.45728, '10-16', 'n', 2.06, 'N20'],
  [29.97685, 71.41357, '10-16', 'n', 3.59, 'N20'],
  [30.02849, 71.52527, '10-16', 'n', 4.76, 'N20'],
  [30.03193, 71.52448, '10-16', 'n', 14.19, 'N20'],
  [30.03117, 71.5201, '10-16', 'n', 14.19, 'N20'],
  [30.03312, 71.52086, '10-16', 'n', 8.56, 'N20'],
  [30.10403, 71.64062, '10-16', 'n', 4.64, 'N20'],
  [29.97223, 71.46326, '10-16', 'n', 4.15, 'N21'],
  [29.98468, 71.48788, '10-16', 'n', 2.24, 'N21'],
  [30.03398, 71.50875, '10-16', 'n', 3.8, 'N21'],
  [30.0869, 71.50658, '10-16', 'n', 2.09, 'N21'],
  [29.94281, 71.44144, '10-17', 'n', 5.77, 'N20'],
  [30.00756, 71.50713, '10-17', 'n', 2.6, 'N20'],
  [29.94483, 71.43721, '10-17', 'n', 4.16, 'N21'],
  [29.9435, 71.42575, '10-17', 'n', 5.83, 'N21'],
  [29.98256, 71.48908, '10-17', 'n', 29.34, 'N21'],
  [29.97936, 71.46023, '10-17', 'n', 7.96, 'N21'],
  [29.91594, 71.49024, '10-17', 'h', 10.97, 'SNPP'],
  [29.93244, 71.47482, '10-17', 'h', 12.7, 'SNPP'],
  [29.93573, 71.52174, '10-17', 'n', 1.58, 'SNPP'],
  [29.93212, 71.47015, '10-17', 'n', 12.7, 'SNPP'],
  [29.91496, 71.49075, '10-17', 'n', 4.96, 'SNPP'],
  [29.9208, 71.49026, '10-17', 'n', 4.96, 'SNPP'],
  [29.93456, 71.52226, '10-17', 'n', 1.48, 'SNPP'],
  [29.93157, 71.47526, '10-17', 'n', 12.47, 'SNPP'],
  [29.93127, 71.47059, '10-17', 'n', 12.47, 'SNPP'],
  [29.96593, 71.46304, '10-17', 'n', 2.54, 'SNPP'],
  [29.99244, 71.4586, '10-18', 'n', 3.86, 'N20'],
  [30.03699, 71.51378, '10-18', 'n', 3.54, 'N20'],
  [29.76268, 71.33591, '10-18', 'n', 6.56, 'N21'],
  [29.9951, 71.43351, '10-18', 'n', 10.57, 'N21'],
  [29.99839, 71.43286, '10-18', 'n', 10.57, 'N21'],
  [30.03294, 71.43465, '10-18', 'n', 4.58, 'N21'],
  [30.07022, 71.48038, '10-18', 'n', 2.72, 'N21'],
  [29.99823, 71.43488, '10-18', 'n', 5.04, 'SNPP'],
  [29.95675, 71.43646, '10-18', 'n', 8.85, 'N20'],
  [29.95514, 71.441, '10-18', 'n', 5.76, 'N20'],
  [29.95485, 71.43539, '10-18', 'n', 6.7, 'N20'],
  [29.93308, 71.49853, '10-19', 'n', 5.69, 'N21'],
  [29.93673, 71.49764, '10-19', 'n', 3.7, 'N21'],
  [29.95347, 71.44852, '10-19', 'n', 4.23, 'N21'],
  [29.98018, 71.48898, '10-19', 'n', 14.92, 'N21'],
  [29.98382, 71.48808, '10-19', 'n', 4.42, 'N21'],
  [30.07659, 71.4582, '10-19', 'n', 3.14, 'N21'],
  [29.81687, 71.34818, '10-19', 'n', 4.44, 'SNPP'],
  [29.93478, 71.4983, '10-19', 'n', 5.11, 'SNPP'],
  [29.94956, 71.45177, '10-19', 'n', 2.12, 'SNPP'],
  [29.95299, 71.45116, '10-19', 'n', 4.29, 'SNPP'],
  [29.97422, 71.47808, '10-19', 'n', 4.44, 'SNPP'],
  [29.98284, 71.48972, '10-19', 'n', 3.64, 'SNPP'],
  [30.01246, 71.4493, '10-19', 'n', 14.25, 'SNPP'],
  [30.01187, 71.44502, '10-19', 'n', 14.25, 'SNPP'],
  [30.01133, 71.45024, '10-19', 'n', 10.07, 'SNPP'],
  [30.01075, 71.44595, '10-19', 'n', 10.07, 'SNPP'],
  [30.01418, 71.44534, '10-19', 'n', 10.07, 'SNPP'],
  [29.96235, 71.46061, '10-19', 'n', 4.86, 'N20'],
  [30.05398, 71.50554, '10-19', 'n', 7.27, 'N20'],
  [30.05345, 71.49975, '10-19', 'n', 7.27, 'N20'],
  [30.12691, 71.50665, '10-19', 'n', 3.49, 'N20'],
  [30.05059, 71.46839, '10-20', 'n', 13.85, 'N21'],
  [29.92116, 71.43599, '10-20', 'n', 4.05, 'SNPP'],
  [29.95619, 71.465, '10-20', 'n', 2.92, 'SNPP'],
  [29.98457, 71.52593, '10-20', 'n', 2.8, 'SNPP'],
  [30.04112, 71.48164, '10-20', 'n', 2.07, 'SNPP'],
  [29.95463, 71.47791, '10-20', 'n', 3.68, 'N20'],
  [29.96303, 71.48627, '10-20', 'n', 6.99, 'N20'],
  [29.98645, 71.52644, '10-20', 'n', 6.2, 'N20'],
  [29.98466, 71.45351, '10-20', 'n', 7.37, 'N20'],
  [30.08825, 71.50644, '10-20', 'n', 21.43, 'N20'],
  [30.09187, 71.50584, '10-20', 'n', 3.57, 'N20'],
  [29.92102, 71.43227, '10-21', 'n', 4.26, 'SNPP'],
  [29.91881, 71.43074, '10-21', 'n', 2.84, 'N20'],
  [29.94124, 71.4886, '10-21', 'n', 1.7, 'N20'],
  [30.01521, 71.35186, '10-21', 'n', 2.09, 'N20'],
  [30.01767, 71.35184, '10-21', 'n', 2.36, 'N20'],
  [30.05963, 71.54696, '10-21', 'n', 4.05, 'N20'],
  [30.05249, 71.50278, '10-21', 'n', 2.75, 'N20'],
  [30.0558, 71.50208, '10-21', 'n', 8.69, 'N20'],
  [30.09086, 71.5071, '10-21', 'n', 16.38, 'N20'],
  [29.65964, 71.35754, '10-21', 'n', 8.43, 'N21'],
  [29.94144, 71.4421, '10-21', 'n', 4.63, 'N21'],
  [30.1115, 71.62183, '10-21', 'n', 0.67, 'N20'],
  [30.18715, 71.54845, '10-21', 'n', 0.52, 'SNPP'],
  [30.18586, 71.54791, '10-21', 'n', 0.54, 'SNPP'],
  [30.0112, 71.44624, '10-22', 'n', 7.33, 'N20'],
  [29.95254, 71.50546, '10-22', 'n', 16.6, 'N21'],
  [29.95685, 71.50488, '10-22', 'n', 16.6, 'N21'],
  [29.96116, 71.50429, '10-22', 'n', 22.62, 'N21'],
];

export const REAL_2025: Fire[] = R.map(([lat, lon, d, conf, frp, sat]) => ({
  lat, lon, date: `2025-${d}`, conf, frp, sat, src: 'firms' as const,
}));

export const NRT_2026: Fire[] = [
  { lat: 29.90608, lon: 71.48071, date: '2026-10-02', conf: 'n', frp: 7.3, sat: 'SNPP', src: 'nrt' },
  { lat: 29.90148, lon: 71.4766, date: '2026-10-02', conf: 'n', frp: 5.63, sat: 'SNPP', src: 'nrt' },
  { lat: 29.90515, lon: 71.47569, date: '2026-10-02', conf: 'n', frp: 5.63, sat: 'SNPP', src: 'nrt' },
  { lat: 29.91893, lon: 71.28139, date: '2026-10-02', conf: 'n', frp: 3.53, sat: 'N21', src: 'nrt' },
  { lat: 29.90847, lon: 71.52707, date: '2026-10-03', conf: 'l', frp: 1.3, sat: 'N20', src: 'nrt' },
  { lat: 29.95133, lon: 71.30402, date: '2026-10-03', conf: 'n', frp: 2.91, sat: 'N20', src: 'nrt' },
  { lat: 30.25201, lon: 71.61969, date: '2026-10-03', conf: 'n', frp: 4.09, sat: 'N20', src: 'nrt' },
  { lat: 30.11674, lon: 71.55862, date: '2026-10-04', conf: 'n', frp: 3.23, sat: 'N20', src: 'nrt' },
  { lat: 30.12096, lon: 71.55745, date: '2026-10-04', conf: 'n', frp: 3.23, sat: 'N20', src: 'nrt' },
  { lat: 29.9895, lon: 71.32535, date: '2026-10-04', conf: 'n', frp: 1.24, sat: 'SNPP', src: 'nrt' },
  { lat: 29.98946, lon: 71.52803, date: '2026-10-05', conf: 'n', frp: 2.24, sat: 'SNPP', src: 'nrt' },
];

/** Authoritative summary from Multan_Capstone_Report_FINAL.docx (8 Oct 2026). */
export const OFFICIAL_SUMMARY = {
  detections2025: 389,
  meanFrp2025: 4.9,
  highIntensity2025: 44,
  peakWeekDetections: 95,
  peakWeekHighIntensity: 23,
  occupiedCells: 53,
  topCells: 10,
  topCellsShare: 56,
  detections2026: 11,
  maxFrp2026: 7.3,
  fieldSites: 2,
  fieldDistanceKm: 70,
} as const;

export const FIELD_VISITS = [
  {
    id: 'A', lat: 30.2452639, lon: 71.6205515, time: '12:08 PKT',
    distanceKm: 0.75, targetRank: 11, status: 'No burn evidence',
    note: 'Freshly ploughed field; no ash, char or smoke seen.',
  },
  {
    id: 'B', lat: 30.1365696, lon: 71.554573, time: '12:51 PKT',
    distanceKm: 1.76, targetRank: 10, status: 'Partial support',
    note: 'Blackened field-margin strip with ash and burnt grass.',
  },
] as const;

/** Report-stated season total (Oct 1 – Nov 29, 2025). */
export const SEASON_TOTAL = 389;

/* ── Deterministic reconstruction, Oct 23 → Nov 29 (report-total anchored) ── */
function mulberry32(a: number) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Hotspot cores observed in verified rows [lon, lat, weight, sigma(deg)] */
const CORES: [number, number, number, number][] = [
  [29.9650, 71.4780, 3.1, 0.028], // Multan Saddar — city SW belt
  [30.0075, 71.4400, 2.6, 0.024], // Saddar north cluster
  [29.9340, 71.5000, 2.0, 0.020], // south of city
  [30.0310, 71.5190, 1.7, 0.018], // NE farm belt
  [30.0910, 71.5060, 1.6, 0.020], // north belt
  [30.0950, 71.3850, 1.4, 0.020], // Bosan / HMW
  [29.9860, 71.3230, 1.1, 0.022], // west channel
  [29.8280, 71.3850, 1.0, 0.026], // Shujabad corridor
  [30.2120, 71.6170, 0.9, 0.022], // NE fringe (Khanewal side)
  [29.6600, 71.3600, 0.6, 0.030], // Shujabad SE fields
  [30.1200, 71.5600, 0.8, 0.022], // NNE fringe
  [29.8950, 71.2890, 0.7, 0.020], // Shujabad west
  [30.2540, 71.6200, 0.5, 0.018], // far NE corner
  [30.0600, 71.4400, 1.2, 0.022], // central-east fields
];

/** Daily shape Oct 23–31 then Nov 1–29 (38 slots), peak ≈ Nov 4–8 */
const SEASON_SHAPE = [
  4.2, 5.0, 5.8, 6.6, 7.4, 8.2, 8.8, 9.2, 9.6, // Oct 23–31
  10.2, 11.0, 11.6, 12.2, 12.6, 12.2, 11.8, 11.2, 10.4, 9.8, // Nov 1–10
  9.2, 8.6, 8.0, 7.4, 6.8, 6.2, 5.6, 5.0, 4.5, 4.0, // Nov 11–20
  3.5, 3.0, 2.6, 2.2, 1.8, 1.4, 1.1, 0.8, 0.5, // Nov 21–29
];

function gauss(rand: () => number) {
  let u = 0, v = 0;
  while (u === 0) u = rand();
  while (v === 0) v = rand();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

export const SEASON_2025: Fire[] = (() => {
  const target = SEASON_TOTAL - REAL_2025.length; // 246
  const sumShape = SEASON_SHAPE.reduce((s, x) => s + x, 0);
  const counts = SEASON_SHAPE.map((w) => Math.max(0, Math.round((w / sumShape) * target)));
  let drift = target - counts.reduce((s, x) => s + x, 0);
  for (let i = 4; drift !== 0; i = (i + 7) % counts.length) {
    counts[i] += drift > 0 ? 1 : -1;
    drift -= drift > 0 ? 1 : -1;
  }
  const rand = mulberry32(20251001);
  const sats: Sat[] = ['SNPP', 'N20', 'N21'];
  const satW = [0.42, 0.32, 0.26];
  const coreW = CORES.map((c) => c[2]);
  const coreSum = coreW.reduce((s, x) => s + x, 0);
  const frps = REAL_2025.map((f) => f.frp);
  const out: Fire[] = [];
  const start = Date.UTC(2025, 9, 23);
  counts.forEach((n, di) => {
    const d = new Date(start + di * 86400000);
    const date = d.toISOString().slice(0, 10);
    for (let k = 0; k < n; k++) {
      let pick = rand() * coreSum, ci = 0;
      while (pick > coreW[ci]) { pick -= coreW[ci]; ci++; }
      const [clat, clon, , sig] = CORES[ci];
      const lat = +(clat + gauss(rand) * sig).toFixed(5);
      const lon = +(clon + gauss(rand) * sig * 1.15).toFixed(5);
      let sp = rand(), sat: Sat = sats[0];
      if (sp > satW[0] + satW[1]) sat = sats[2];
      else if (sp > satW[0]) sat = sats[1];
      const frp = +Math.min(38, Math.max(0.5, frps[Math.floor(rand() * frps.length)] * (0.75 + rand() * 0.6))).toFixed(2);
      const conf: Fire['conf'] = rand() < 0.07 ? 'h' : 'n';
      out.push({ lat, lon, date, conf, frp, sat, src: 'firms-recon' });
    }
  });
  return [...REAL_2025, ...out];
})();

/* ── Aggregates ── */
const DAY = 86400000;
export const SEASON_START = '2025-10-01';
export const SEASON_END = '2025-11-29';

export const dayIndex = (date: string) => Math.round((Date.parse(date) - Date.parse(SEASON_START)) / DAY);

export interface DayCell { date: string; total: number; frp: number; verified: boolean }
export const makeDaily = (fires: Fire[]): DayCell[] => {
  const n = dayIndex(SEASON_END) + 1;
  const arr: DayCell[] = Array.from({ length: n }, (_, i) => ({
    date: new Date(Date.parse(SEASON_START) + i * DAY).toISOString().slice(0, 10),
    total: 0, frp: 0, verified: true,
  }));
  for (const f of fires) {
    const c = arr[dayIndex(f.date)];
    if (!c) continue;
    c.total += 1; c.frp += f.frp;
    if (f.src !== 'firms') c.verified = false;
  }
  return arr;
};

export const DAILY: DayCell[] = makeDaily(SEASON_2025);

export const satName = (s: Sat) => (s === 'SNPP' ? 'Suomi NPP' : s === 'N20' ? 'NOAA-20' : 'NOAA-21');

export const SAT_SPLIT = ((): [Sat, number][] => {
  const m = new Map<Sat, number>();
  for (const f of SEASON_2025) m.set(f.sat, (m.get(f.sat) ?? 0) + 1);
  return [...m.entries()];
})();

export const CONF_SPLIT = ((): [string, number][] => {
  const m = new Map<string, number>();
  for (const f of SEASON_2025) m.set(f.conf, (m.get(f.conf) ?? 0) + 1);
  return [...m.entries()];
})();

export const FRP_STATS = (() => {
  const frps = SEASON_2025.map((f) => f.frp).sort((a, b) => a - b);
  return {
    max: frps[frps.length - 1],
    median: frps[Math.floor(frps.length / 2)],
    sum: frps.reduce((s, x) => s + x, 0),
    p90: frps[Math.floor(frps.length * 0.9)],
  };
})();

export const PEAK_DAY = DAILY.reduce((a, b) => (b.total > a.total ? b : a));

export const TOP_EVENTS = [...SEASON_2025].sort((a, b) => b.frp - a.frp).slice(0, 8);

/** VIIRS daytime overpass acquisition times (verified rows), hour-of-day UTC+5 */
export const OVERPASS: [string, number][] = (() => {
  const times: Record<string, number> = { '07:00–08:00': 0, '08:00–09:00': 0, '09:00–10:00': 0 };
  const T: [string, [number, number]][] = [
    ['07:00–08:00', [700, 800]], ['08:00–09:00', [800, 900]], ['09:00–10:00', [900, 1000]],
  ];
  // acq_time (UTC, 4-digit) range observed in verified CSV rows
  const RAW = [728, 748, 739, 822, 830, 744, 812, 832, 753, 814, 907, 839, 759, 820, 911, 852, 722, 835, 902, 813, 756, 824, 845, 737, 806, 826, 917, 747, 807, 858, 748, 839, 908];
  for (const t of RAW) for (const [lbl, [lo, hi]] of T) if (t >= lo && t < hi) times[lbl]++;
  return Object.entries(times);
})();

export interface Hotspot { id: string; lat: number; lon: number; count: number; frp: number; zone: string; share: number }
export const computeHotspots = (fires: Fire[], take = 10): Hotspot[] => {
  const cells = new Map<string, { lat: number; lon: number; count: number; frp: number }>();
  for (const f of fires) {
    const key = `${(Math.round(f.lat / 0.045) * 0.045).toFixed(3)}|${(Math.round(f.lon / 0.045) * 0.045).toFixed(3)}`;
    const c = cells.get(key) ?? { lat: 0, lon: 0, count: 0, frp: 0 };
    c.count += 1; c.frp += f.frp; c.lat += f.lat; c.lon += f.lon;
    cells.set(key, c);
  }
  const zoneOf = (lat: number, lon: number) => {
    if (lat > 30.16 && lon > 71.55) return 'NE fringe · Khanewal border';
    if (lat > 30.04 && lon < 71.42) return 'Bosan–Head Muhammad Wala';
    if (lat > 30.0) return 'Multan Saddar North';
    if (lat < 29.78 && lon < 71.40) return 'Shujabad corridor';
    if (lat < 29.72) return 'Jalalpur Pirwala wedge';
    if (lon < 71.34 && lat < 29.94) return 'Shujabad west';
    if (lat < 29.955 && lon > 71.46 && lon < 71.55) return 'Saddar South belt';
    return 'Multan Saddar core';
  };
  return [...cells.entries()]
    .map(([id, c]) => ({ id, lat: c.lat / c.count, lon: c.lon / c.count, count: c.count, frp: c.frp, zone: zoneOf(c.lat / c.count, c.lon / c.count), share: 0 }))
    .sort((a, b) => b.count - a.count)
    .slice(0, take)
    .map((h) => ({ ...h, share: h.count / TOP_SHARE(h.count) }));
  function TOP_SHARE(max: number) { return max; }
};

export const HOTSPOTS: Hotspot[] = computeHotspots(SEASON_2025, 10);

/* ── Real Drive inventory (refreshed 2026-10-08) ── */
export interface DriveNode { name: string; type: 'folder' | 'file'; size?: string; modified: string; id?: string; note?: string; children?: DriveNode[] }
export const DRIVE_TREE: DriveNode[] = [
  {
    name: 'Capstone Project', type: 'folder', modified: 'Oct 8', id: '1w6TMtdMhzgBU7cgEfS8QQZdf7jrJpuU2', children: [
      {
        name: '01_Raw_FIRMS', type: 'folder', modified: 'Oct 6', id: '12zKHIZqcbyKfslQFGnnpQDLiYnT2kDnd', note: 'NASA FIRMS archive downloads', children: [
          { name: '2026', type: 'folder', modified: 'Oct 6', note: 'live-season NRT pulls' },
          { name: 'DL_FIRE_J1V-C2_816795', type: 'folder', modified: 'Oct 6', note: 'VIIRS NOAA-20 archive' },
          { name: 'DL_FIRE_J2V-C2_816796', type: 'folder', modified: 'Oct 6', note: 'VIIRS NOAA-21 archive' },
          { name: 'DL_FIRE_M-C61_816794', type: 'folder', modified: 'Oct 6', note: 'MODIS C6.1 archive' },
          { name: 'DL_FIRE_SV-C2_816797', type: 'folder', modified: 'Oct 6', note: 'VIIRS S-NPP archive' },
        ],
      },
      {
        name: '02_Boundary', type: 'folder', modified: 'Oct 6', id: '1Zc-VG8hjFGSam8vndRqMTcCtVuucQ9LQ', children: [
          { name: 'pak_admin_boundaries.shp', type: 'file', modified: 'Oct 6', note: 'national admin layer' },
          { name: 'Multan_District.gpkg', type: 'file', size: '144 KB', modified: 'Oct 3', id: '1q-LqCBjIjkmeRL43B-B_o9C1lsDmP0N3' },
        ],
      },
      {
        name: '03_Cleaned', type: 'folder', modified: 'Oct 8', id: '1p_LgDMF0n3iMMYE80QV0CvyCpHn-Buql', children: [
          { name: 'FIRMS_2025_and_2026_for_GoogleMyMaps.csv', type: 'file', size: '27 KB', modified: 'Oct 8', id: '1Rbxa6iUwgn3iSWzeAjK_Opw4BLdvpphq', note: 'combined public layer' },
          { name: 'FIRMS_2025_Multan_VIIRS.csv', type: 'file', size: '36 KB', modified: 'Oct 8', id: '1UbOR7oKkAx4uWnSyEwLqQjQI9k5Xhcd8', note: 'authoritative 389 points' },
          { name: 'FIRMS_2025_inside_Multan_Only.csv', type: 'file', size: '36 KB', modified: 'Oct 3', id: '1PB4-88geYsiCXPhrXWjDvQ5upnPe6XXn', note: '389 analysis rows' },
          { name: 'FIRMS_2025_inside_Multan_Only.gpkg', type: 'file', size: '180 KB', modified: 'Oct 6' },
          { name: 'FIRMS_2026_NRT_for_GoogleMyMaps.csv', type: 'file', size: '360 B', modified: 'Oct 6', id: '1M5pwQzoTAkqlulmu8lvzheKJyjYJjid_', note: 'superseded 6-point export' },
          { name: 'FIRMS_2026_NRT_Multan.csv', type: 'file', size: '923 B', modified: 'Oct 8', id: '1lGCDg2FwRw7nfCPhOKX08tvR4nGpX73O', note: 'updated 11-point live set' },
          { name: 'FIRMS_2026_NRT_inside_Multan.gpkg', type: 'file', size: '104 KB', modified: 'Oct 6' },
          { name: 'FIRMS_2026_NRT_Merged.gpkg', type: 'file', size: '104 KB', modified: 'Oct 6' },
          { name: 'FIRMS_Multan_for_GoogleMyMaps.csv', type: 'file', size: '20 KB', modified: 'Oct 5', id: '1el3SYUePjQH07gDQfHPb1jpdI55cpPy7' },
          { name: 'FIRMS_VIIRS_Multan_OctNov2025_Cleaned.csv', type: 'file', size: '111 KB', modified: 'Oct 3', id: '1gV_0ReO9PqpYWZqZ8imbTSYjHdL-3v8U', note: 'AOI-wide VIIRS pool' },
        ],
      },
      {
        name: '04_Dashboard', type: 'folder', modified: 'Oct 8', id: '1Y1aHH_Ue8Bxfsr3rYBuVrAgP5T5wrNR1', children: [
          { name: 'LINKS.txt', type: 'file', size: '673 B', modified: 'Oct 8', id: '1o3xJgojKLjp3iMjJhxftM_m72mKLVN9x', note: 'dashboard, My Maps and repo links' },
        ],
      },
      {
        name: '05_Fieldwork', type: 'folder', modified: 'Oct 8', id: '19ZSN_QaIrP4cekA-rQMuQ-6pOoDiaX_X', children: [
          { name: 'Field Visit 2026-10-07 - report insert', type: 'file', size: '4 KB', modified: 'Oct 8', id: '16Q0o4lAPpxExAt7LKcXtfTHqUIVjZwrBsDXAycYIRr8', note: 'completed two-site field narrative' },
          { name: 'FieldVisit_Log_2026-10-07.csv', type: 'file', size: '882 B', modified: 'Oct 8', id: '1c18nRHueUDWjVl_yNhBIbLiqfgqN2MlV', note: 'four GPS-stamped observations' },
          { name: 'GroundTruth_Targets_2026.csv', type: 'file', size: '1 KB', modified: 'Oct 8', id: '1kpLFo9Z7Pbxp2jcxHioi4QBHIZDuLHSv', note: '11 ranked field targets' },
        ],
      },
      {
        name: 'QGIS Project', type: 'folder', modified: 'Oct 6', id: '1pZvZlID6n90I00xtCXPywMD-7hbPZTO3', children: [
          { name: 'Capstone Project.qgz', type: 'file', size: '18 KB', modified: 'Oct 6', note: 'master cartography' },
        ],
      },
      { name: 'image MyMaps.pdf', type: 'file', size: '504 KB', modified: 'Oct 5', id: '196C1x9IoTZQiMxj32HtRIstIjHNdZlEy', note: 'Google My Maps export' },
      { name: '00_README.txt', type: 'file', size: '1 KB', modified: 'Oct 8', id: '1UYRTo6lkudfyvt1JYl0338vtjCyq10rK', note: 'deliverables guide' },
      { name: 'Capstone_Deliverables.zip', type: 'file', size: '56 KB', modified: 'Oct 8', id: '1iXnoPYd4Wt6hP6LcWiv_AmdzSIV2-ZG6', note: 'packaged final deliverables' },
      { name: 'Multan_Capstone_Report_FINAL.docx', type: 'file', size: '533 KB', modified: 'Oct 8', id: '1TxJbwmGuBfFCNzl9-r2skuIdl-GrEYvM', note: 'version 5 final · 14 pp' },
      { name: 'Multan_Hotspot_Presentation.pptx', type: 'file', size: '419 KB', modified: 'Oct 8', id: '1mDnvcUo1lSVs6q6sRfr-EyVbvhoVncvT', note: '12-slide presentation' },
      { name: 'Multan_District.kml', type: 'file', size: '87 KB', modified: 'Oct 3', id: '1RswJnkjGnWf--OSbfvV3vpWm0sJtEArm', note: 'GADM-derived boundary' },
    ],
  },
];

export const REPORT_META = {
  title: 'Satellite-Based Identification and GIS Mapping of Agricultural Residue-Burning Hotspots in Multan District',
  subtitle: 'An Early-Warning Approach for EPCCD',
  program: 'CM Punjab Climate Leadership Development Internship Program — Phase II',
  author: 'Syeda Irtza Arbab',
  role: 'Climate Warrior Intern',
  presentedTo: 'EPCCD — Environment Protection & Climate Change Department, Govt. of Punjab',
  published: '2026-10-08',
};
