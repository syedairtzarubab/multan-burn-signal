import { useEffect, useState } from 'react';
import { SEASON_2025, type Fire, type Sat } from './fires';

// Public companion repository listed in 04_Dashboard/LINKS.txt. Its compact
// file contains all 389 authoritative 2025 detections from the final report.
export const OFFICIAL_2025_URL =
  'https://raw.githubusercontent.com/musab-shahid/multan-hotspot-dashboard/main/pts_compact.json';

type CompactFire = [number, number, number, number, number, 'l' | 'n' | 'h'];

const sats: Sat[] = ['SNPP', 'N20', 'N21'];
let cache: Fire[] | null = null;
let pending: Promise<Fire[]> | null = null;

function decode(rows: CompactFire[]): Fire[] {
  const start = Date.UTC(2025, 9, 1);
  return rows.map(([lat, lon, day, frp, sat, conf]) => ({
    lat,
    lon,
    date: new Date(start + day * 86400000).toISOString().slice(0, 10),
    frp,
    sat: sats[sat] ?? 'SNPP',
    conf,
    src: 'firms' as const,
  }));
}

function loadOfficial() {
  if (cache) return Promise.resolve(cache);
  if (!pending) {
    pending = fetch(OFFICIAL_2025_URL)
      .then((response) => {
        if (!response.ok) throw new Error(`FIRMS data fetch failed: ${response.status}`);
        return response.json() as Promise<CompactFire[]>;
      })
      .then((rows) => {
        const decoded = decode(rows);
        if (decoded.length !== 389) throw new Error(`Expected 389 detections; received ${decoded.length}`);
        cache = decoded;
        return decoded;
      });
  }
  return pending;
}

export function useOfficialFires() {
  const [fires, setFires] = useState<Fire[]>(cache ?? SEASON_2025);
  const [official, setOfficial] = useState(Boolean(cache));

  useEffect(() => {
    let active = true;
    loadOfficial()
      .then((rows) => {
        if (!active) return;
        setFires(rows);
        setOfficial(true);
      })
      .catch((error) => console.warn('Using embedded season fallback:', error));
    return () => { active = false; };
  }, []);

  return { fires, official };
}

export function fireStats(fires: Fire[]) {
  const sorted = fires.map((f) => f.frp).sort((a, b) => a - b);
  return {
    max: sorted.at(-1) ?? 0,
    median: sorted[Math.floor(sorted.length / 2)] ?? 0,
    p90: sorted[Math.floor(sorted.length * 0.9)] ?? 0,
    sum: sorted.reduce((sum, value) => sum + value, 0),
    mean: sorted.reduce((sum, value) => sum + value, 0) / Math.max(1, sorted.length),
    high: sorted.filter((value) => value > 10).length,
  };
}