import { useEffect, useState } from 'react';
import { Flame, Satellite, Radio, Menu, X } from 'lucide-react';
import { cn } from '../utils/cn';

const NAV = [
  ['Season Map', '#map'],
  ['Analytics', '#analytics'],
  ['Hotspots', '#hotspots'],
  ['Pipeline', '#pipeline'],
  ['Report', '#report'],
] as const;

function useClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(iv);
  }, []);
  const fmt = (d: Date, off: number) => {
    const t = new Date(d.getTime() + (off + d.getTimezoneOffset() / 60) * 3600000);
    return t.toTimeString().slice(0, 8);
  };
  return { utc: fmt(now, 0), pkt: fmt(now, 5) };
}

export default function TopBar() {
  const { utc, pkt } = useClock();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', on, { passive: true });
    return () => window.removeEventListener('scroll', on);
  }, []);

  return (
    <header className={cn('fixed inset-x-0 top-0 z-50 transition-all duration-500', scrolled ? 'bg-ink/85 backdrop-blur-xl border-b border-white/8' : 'bg-transparent')}>
      <div className="mx-auto flex max-w-[1500px] items-center gap-4 px-5 py-3.5 md:px-8">
        <a href="#top" className="group flex items-center gap-3">
          <span className="grid h-9 w-9 place-items-center rounded-md border border-ember/50 bg-ember/10 text-ember transition-all group-hover:bg-ember/20">
            <Flame size={17} strokeWidth={2.2} />
          </span>
          <span className="leading-tight">
            <span className="block text-[13px] font-semibold tracking-[0.18em] text-ash">BURN SIGNAL</span>
            <span className="block font-mono text-[9px] uppercase tracking-[0.28em] text-smoke">Multan Sector · EPCCD</span>
          </span>
        </a>

        <nav className="ml-8 hidden items-center gap-1 lg:flex">
          {NAV.map(([label, href]) => (
            <a key={href} href={href} className="rounded px-3 py-1.5 font-mono text-[10.5px] uppercase tracking-[0.18em] text-smoke transition-colors hover:bg-white/5 hover:text-flare">
              {label}
            </a>
          ))}
        </nav>

        <div className="ml-auto hidden items-center gap-2 md:flex">
          <span className="glass hidden items-center gap-2 rounded-full px-3 py-1.5 font-mono text-[10px] tracking-[0.14em] text-smoke xl:flex">
            <Satellite size={11} className="text-ember" />
            S-NPP · NOAA-20 · NOAA-21
            <span className="h-1 w-1 rounded-full bg-emerald-400" style={{ boxShadow: '0 0 6px #34d399' }} />
          </span>
          <span className="glass flex items-center gap-2 rounded-full px-3 py-1.5 font-mono text-[10px] tracking-[0.14em]">
            <Radio size={11} className="text-ice" />
            <span className="text-ash">{pkt}</span>
            <span className="text-smoke">PKT</span>
            <span className="text-smoke/50">·</span>
            <span className="text-smoke">{utc} UTC</span>
          </span>
        </div>

        <button onClick={() => setOpen(!open)} className="glass ml-auto grid h-9 w-9 place-items-center rounded-md text-ash lg:hidden" aria-label="menu">
          {open ? <X size={16} /> : <Menu size={16} />}
        </button>
      </div>

      {open && (
        <nav className="border-t border-white/8 bg-ink/95 px-6 py-4 backdrop-blur-xl lg:hidden">
          {NAV.map(([label, href]) => (
            <a key={href} href={href} onClick={() => setOpen(false)} className="block border-b border-white/5 py-3 font-mono text-[11px] uppercase tracking-[0.22em] text-smoke hover:text-flare">
              {label}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
}
