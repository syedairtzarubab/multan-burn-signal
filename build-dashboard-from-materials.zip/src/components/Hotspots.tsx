import { useMemo } from 'react';
import { MapPin, Flame, Route } from 'lucide-react';
import { computeHotspots, OFFICIAL_SUMMARY, SEASON_TOTAL } from '../data/fires';
import { useOfficialFires } from '../data/official';
import { MAP_W, MAP_H, MapCanvasDefs, Boundary, project } from './MapCore';
import { SectionHead, Corner, Chip } from './ui';

export default function Hotspots() {
  const { fires } = useOfficialFires();
  const hotspots = useMemo(() => computeHotspots(fires, 10), [fires]);
  const maxBar = hotspots[0]?.count ?? 1;
  return (
    <section id="hotspots" className="relative border-t border-white/8">
      <div className="mx-auto max-w-[1500px] px-5 py-24 md:px-8 md:py-32">
        <SectionHead
          no="03"
          kicker="Ignition geography"
          title={<>Where detections concentrate —<br /><span className="text-smoke">the ten cells EPCCD should watch first.</span></>}
          right={<Chip>grid ≈ 5 km cells</Chip>}
        />

        <div className="grid gap-6 lg:grid-cols-12">
          {/* locator */}
          <div className="rv relative lg:col-span-5">
            <div className="glass edge-glow relative h-full overflow-hidden rounded-2xl">
              <Corner />
              <div className="border-b border-white/8 px-5 py-3">
                <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-smoke">Hotspot locator · ranked cells</p>
              </div>
              <svg viewBox={`0 0 ${MAP_W} ${MAP_H}`} className="mx-auto max-h-[62vh] w-full bg-[#080a0e]" preserveAspectRatio="xMidYMid meet">
                <MapCanvasDefs />
                <Boundary />
                {hotspots.map((h, i) => {
                  const [x, y] = project(h.lon, h.lat);
                  const r = 15 + (h.count / maxBar) * 20;
                  return (
                    <g key={h.id}>
                      <circle cx={x} cy={y} r={r} fill="none" stroke="#ff6a1f" strokeOpacity="0.35" strokeDasharray="3 5" />
                      <circle cx={x} cy={y} r={r * 0.55} fill="#ff6a1f" fillOpacity="0.14" />
                      <circle cx={x} cy={y} r="13" fill="#0b0e13" stroke="#ffb020" strokeWidth="1.4" filter="url(#fGlow)" />
                      <text x={x} y={y + 4.2} textAnchor="middle" fill="#ffb020" fontSize="12" fontWeight="700" fontFamily="JetBrains Mono">{i + 1}</text>
                      <text x={x} y={y + r + 15} textAnchor="middle" fill="#8b93a1" fontSize="10" fontFamily="JetBrains Mono">{h.count} fr</text>
                    </g>
                  );
                })}
              </svg>
              <div className="border-t border-white/8 bg-panel px-5 py-4">
                <p className="text-[12px] leading-relaxed text-smoke">
                  Concentration is substantial: the final analysis found <span className="text-ash">53 occupied 5 km cells</span>,
                  with the top {OFFICIAL_SUMMARY.topCells} holding <span className="text-flare">{OFFICIAL_SUMMARY.topCellsShare}%</span> of all 389 detections.
                  Most lie in a belt 14–31 km south of Multan city.
                </p>
              </div>
            </div>
          </div>

          {/* ranked list */}
          <div className="lg:col-span-7">
            <ol className="space-y-3">
              {hotspots.map((h, i) => (
                <li key={h.id} className={`rv rv-d${Math.min(i + 1, 4)} group relative overflow-hidden rounded-xl border border-white/8 bg-panel/70 px-5 py-4 transition-all hover:border-ember/40 hover:bg-panel2`}>
                  <div className="flex items-center gap-4">
                    <span className="num grid h-11 w-11 shrink-0 place-items-center rounded-lg border border-ember/40 bg-ember/10 text-lg font-bold text-flare">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-baseline gap-x-3">
                        <p className="truncate text-[15px] font-medium text-ash">{h.zone}</p>
                        <p className="font-mono text-[9.5px] tracking-[0.14em] text-smoke/70">
                          {h.lat.toFixed(3)}°N {h.lon.toFixed(3)}°E
                        </p>
                      </div>
                      <div className="mt-2 flex items-center gap-3">
                        <div className="h-1.5 max-w-md flex-1 overflow-hidden rounded-full bg-white/6">
                          <div className="h-full rounded-full bg-gradient-to-r from-ember to-flare transition-all duration-700 group-hover:shadow-[0_0_12px_rgba(255,176,32,.5)]" style={{ width: `${(h.count / maxBar) * 100}%` }} />
                        </div>
                        <span className="num font-mono text-[10px] text-smoke">{((h.count / SEASON_TOTAL) * 100).toFixed(1)}%</span>
                      </div>
                    </div>
                    <div className="hidden shrink-0 text-right sm:block">
                      <p className="num flex items-center justify-end gap-1.5 text-xl font-semibold text-flare"><Flame size={13} className="text-ember" />{h.count}</p>
                      <p className="num font-mono text-[9.5px] tracking-[0.1em] text-smoke/70">Σ {h.frp.toFixed(0)} MW</p>
                    </div>
                  </div>
                </li>
              ))}
            </ol>

            <div className="rv rv-d3 mt-5 flex items-start gap-3 rounded-xl border border-ice/20 bg-ice/5 px-5 py-4">
              <Route size={16} className="mt-0.5 shrink-0 text-ice" />
              <p className="text-[12.5px] leading-relaxed text-smoke">
                <span className="text-ice">Field lesson —</span> rank visits by travel time from the field office, not
                distance from the district centroid. The 7 October visit found wrong directions, missing farm roads,
                and 0.75–1.8 km offsets; use offline maps, a 1–2 km search radius, daylight teams, and a 24–48 hour response.
              </p>
            </div>

            <div className="rv rv-d4 mt-5 flex flex-wrap items-center gap-2">
              <MapPin size={13} className="text-ember" />
              <span className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-smoke">Cross-check zones against MyMaps export · image MyMaps.pdf (504 KB, Drive)</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
