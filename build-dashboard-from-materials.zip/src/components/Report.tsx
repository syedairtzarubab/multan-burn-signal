import { ExternalLink, FileText, Scale, EyeOff, RotateCcw, Unplug, GraduationCap, Quote, Radar, Target, AlertTriangle, CheckCircle2, MapPin, Camera, Clock3, ShieldAlert } from 'lucide-react';
import { REPORT_META } from '../data/fires';
import { SectionHead, Corner, Chip } from './ui';

const GAPS = [
  { icon: EyeOff, title: 'No detection infrastructure', body: 'EPCCD and district authorities cannot know where burning is actively happening without waiting for visible-smog complaints — by which point exposure has already occurred.' },
  { icon: RotateCcw, title: 'Reactive, not preventive', body: 'Without localized timely data, interventions default to broad, resource-inefficient awareness drives instead of targeted outreach at the villages where fires concentrate.' },
  { icon: Unplug, title: 'A free data source unused', body: 'Near-daily satellite fire data already exists and is used for exactly this purpose across the border — but had never been translated into a Multan-district decision tool.' },
];

const OBJECTIVES = [
  'Map the spatial & temporal distribution of residue-burning hotspots for Oct–Nov 2025 and the live Oct 2026 season.',
  'Ground-truth the highest-density hotspots through direct field visits, separating residue fires from other heat sources.',
  'Review PEPA and EPCCD enforcement capacity to locate the gap between legal provision and monitoring reality.',
  'Assess the feasibility of a satellite-driven early-warning dashboard — manual refresh, resolution and confidence trade-offs included.',
  'Produce evidence-based recommendations for integrating hotspot monitoring into the district enforcement workflow.',
];

const LIMITS = [
  'Daylight passes only — overnight fires between overpasses slip through',
  '375 m pixels merge adjacent small plots into single detections',
  'Cloud or thick smoke can mask active fires on a given pass',
  'Confidence filtering trades coverage for certainty',
  'Refresh is manual — not yet a live NRT feed to EPCCD',
  'A detection is a search area, not proof of residue burning',
  'The field sample covered only two sites, 3–4 days after detection',
];

export default function Report() {
  return (
    <section id="report" className="relative border-t border-white/8">
      <div className="mx-auto max-w-[1500px] px-5 py-24 md:px-8 md:py-32">
        <SectionHead
          no="05"
          kicker="The field brief · digested"
          title={<>Not a data problem —<br /><span className="text-smoke">a translation problem.</span></>}
          right={
            <a href="https://drive.google.com/file/d/1TxJbwmGuBfFCNzl9-r2skuIdl-GrEYvM" target="_blank" rel="noreferrer"
              className="group inline-flex items-center gap-2 rounded-full border border-white/15 px-4 py-2 font-mono text-[10px] uppercase tracking-[0.18em] text-smoke transition-all hover:border-flare/60 hover:text-flare">
              Final report · 14 pp <ExternalLink size={11} />
            </a>
          }
        />

        {/* framing quote */}
        <div className="rv relative mb-16 max-w-4xl">
          <Quote size={44} className="absolute -left-2 -top-4 text-ember/20" />
          <p className="text-balance pl-10 text-xl font-light leading-[1.5] text-ash/90 md:text-[1.7rem]">
            “The 2025 detections are concentrated, not spread evenly: 10 of the 53 five-kilometre cells
            hold <span className="text-flare">56% of all detections</span>. The field visit gave partial support only —
            one small burnt strip near a detection, and no evidence at the second site.”
          </p>
          <p className="mt-5 pl-10 font-mono text-[10px] uppercase tracking-[0.24em] text-smoke">
            — Multan_Capstone_Report_FINAL.docx · Executive Summary
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-12">
          {/* gaps */}
          <div className="space-y-4 lg:col-span-5">
            {GAPS.map((g, i) => (
              <div key={g.title} className={`rv rv-d${i} group relative overflow-hidden rounded-2xl border border-white/8 bg-panel/70 p-6 transition-colors hover:border-ember/35`}>
                <span className="num absolute right-5 top-4 font-mono text-4xl font-bold text-white/6">0{i + 1}</span>
                <span className="grid h-10 w-10 place-items-center rounded-lg border border-rose/40 bg-rose/10 text-rose">
                  <g.icon size={17} />
                </span>
                <p className="mt-4 pr-16 text-[15px] font-medium text-ash">{g.title}</p>
                <p className="mt-1.5 text-[12.5px] leading-relaxed text-smoke">{g.body}</p>
              </div>
            ))}
          </div>

          {/* objectives */}
          <div className="rv rv-d1 relative overflow-hidden rounded-2xl border border-white/8 bg-panel/70 lg:col-span-7">
            <Corner />
            <div className="border-b border-white/8 px-6 py-4">
              <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-smoke">
                <Target size={12} className="text-ember" /> Capstone objectives — verbatim scope
              </p>
            </div>
            <ol className="divide-y divide-white/6">
              {OBJECTIVES.map((o, i) => (
                <li key={i} className="group flex items-start gap-4 px-6 py-4 transition-colors hover:bg-white/[0.03]">
                  <span className="num mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full border border-flare/40 bg-flare/10 font-mono text-[10px] font-bold text-flare">{i + 1}</span>
                  <p className="text-[13px] leading-relaxed text-smoke group-hover:text-ash/90">{o}</p>
                  {i === 0 && <CheckCircle2 size={14} className="ml-auto mt-1 shrink-0 text-emerald-400/80" />}
                  {i === 3 && <Radar size={14} className="ml-auto mt-1 shrink-0 text-ice/80" />}
                </li>
              ))}
            </ol>
            <div className="flex flex-wrap gap-2 border-t border-white/8 bg-ink/40 px-6 py-4">
              <Chip active>objectives 1–5 completed</Chip>
              <Chip>baseline: Oct 1 – Nov 29 ’25</Chip>
              <Chip>live season: Oct ’26 →</Chip>
            </div>
          </div>
        </div>

        {/* completed field verification */}
        <div className="rv mt-6 relative overflow-hidden rounded-2xl border border-ice/25 bg-gradient-to-br from-ice/[0.06] via-panel to-panel">
          <Corner />
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/8 px-6 py-4">
            <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-ice"><MapPin size={12} /> Field verification · 7 October 2026</p>
            <div className="flex gap-2"><Chip>2 sites</Chip><Chip>~70 km</Chip><Chip>3–4 day lag</Chip></div>
          </div>
          <div className="grid md:grid-cols-2">
            <div className="border-b border-white/8 p-6 md:border-b-0 md:border-r">
              <div className="flex items-center justify-between">
                <p className="text-lg font-medium text-ash">Site A · Sadiq Abad Road</p>
                <span className="font-mono text-[10px] text-rose">NO BURN EVIDENCE</span>
              </div>
              <p className="mt-1 font-mono text-[9.5px] tracking-[0.12em] text-smoke">30.24526°N, 71.62055°E · 12:08 PKT · 0.75 km from target</p>
              <p className="mt-4 text-[12.5px] leading-relaxed text-smoke">Freshly ploughed bare soil with green crops and tree lines; no ash, char or smoke. Four days had passed, so ploughing, watering or wind may have removed evidence, but that cannot be established.</p>
            </div>
            <div className="p-6">
              <div className="flex items-center justify-between">
                <p className="text-lg font-medium text-ash">Site B · 4HP3+WGP</p>
                <span className="font-mono text-[10px] text-flare">PARTIAL SUPPORT</span>
              </div>
              <p className="mt-1 font-mono text-[9.5px] tracking-[0.12em] text-smoke">30.13657°N, 71.55458°E · 12:51 PKT · 1.76 km from target</p>
              <p className="mt-4 text-[12.5px] leading-relaxed text-smoke">A blackened strip of soil and burnt grass was documented along a field margin. It is consistent with small-scale burning, but does not prove that the nearby 3.23 MW satellite signal came from that exact spot.</p>
            </div>
          </div>
          <div className="grid gap-px border-t border-white/8 bg-white/8 md:grid-cols-4">
            {([
              [Camera, 'Evidence', 'GPS-stamped photos and four logged observations'],
              [Clock3, 'Response', 'Visit within 24–48 hours, not 3–4 days'],
              [Radar, 'Search radius', 'Treat each point as a 1–2 km search area'],
              [ShieldAlert, 'Safety', 'Groups, daylight, authorisation and live location'],
            ] as [typeof Camera, string, string][]).map(([Icon, title, text]) => (
              <div key={title} className="bg-panel/90 p-4">
                <Icon size={14} className="text-ice" />
                <p className="mt-2 text-[12px] font-medium text-ash">{title}</p>
                <p className="mt-1 text-[10.5px] leading-relaxed text-smoke">{text}</p>
              </div>
            ))}
          </div>
        </div>

        {/* policy + limits + author */}
        <div className="mt-6 grid gap-6 lg:grid-cols-12">
          <div className="rv relative overflow-hidden rounded-2xl border border-white/8 bg-panel/70 p-6 lg:col-span-4">
            <Corner />
            <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-smoke"><Scale size={12} className="text-ember" /> Policy frame</p>
            <p className="mt-4 text-[15px] font-medium text-ash">PEPA 1997 (am. 2012)</p>
            <p className="mt-2 text-[12.5px] leading-relaxed text-smoke">
              Pakistan’s Environmental Protection Act provides the legal basis against open burning in Punjab —
              but enforcement has relied on manual inspection and complaint-driven response. Satellite detection
              converts that standing legal expectation into <span className="text-ash/90">same-day, GPS-located
              field intelligence</span> the Act never had.
            </p>
            <div className="mt-5 border-t border-white/8 pt-4">
              <p className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-smoke/70">
                Sector precedent · Indian Punjab has run FIRMS-based residue dashboards for over a decade
              </p>
            </div>
          </div>

          <div className="rv rv-d1 relative overflow-hidden rounded-2xl border border-white/8 bg-panel/70 p-6 lg:col-span-4">
            <Corner />
            <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-smoke"><AlertTriangle size={12} className="text-ember" /> Honest limitations</p>
            <ul className="mt-4 space-y-2.5">
              {LIMITS.map((l) => (
                <li key={l} className="flex items-start gap-2.5 text-[12px] leading-relaxed text-smoke">
                  <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-ember/80" />{l}
                </li>
              ))}
            </ul>
          </div>

          <div className="rv rv-d2 relative overflow-hidden rounded-2xl border border-ember/30 bg-gradient-to-b from-ember/10 via-panel to-panel p-6 lg:col-span-4">
            <Corner />
            <div className="flex items-start justify-between">
              <span className="grid h-12 w-12 place-items-center rounded-xl border border-flare/50 bg-flare/10 text-flare">
                <GraduationCap size={20} />
              </span>
              <Chip>Phase II · 2026</Chip>
            </div>
            <p className="mt-5 text-lg font-medium leading-snug text-ash">{REPORT_META.author}</p>
            <p className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-flare/90">{REPORT_META.role}</p>
            <p className="mt-3 text-[12.5px] leading-relaxed text-smoke">
              {REPORT_META.program}. Presented to <span className="text-ash/90">{REPORT_META.presentedTo}</span>.
            </p>
            <div className="mt-5 space-y-1.5 border-t border-white/10 pt-4 font-mono text-[9.5px] uppercase tracking-[0.14em] text-smoke/70">
              <p className="flex items-center gap-2"><FileText size={10} className="text-ember/70" /> Multan_Capstone_Report_FINAL.docx · 533 KB · 14 pp</p>
              <p>Published {REPORT_META.published} · EPCCD early-warning feasibility study</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
