import { useEffect, useState } from 'react';
import { cn } from '../utils/cn';

const LINES = [
  'EPCCD · MULTAN SECTOR · LINK ESTABLISHED',
  'VIIRS S-NPP / NOAA-20 / NOAA-21 — 375 m TIR CHANNEL OK',
  'BOUNDARY LOCK: MULTAN DISTRICT PK622 · 3,648 KM²',
  '389 SEASON DETECTIONS · 11 NRT · 2 FIELD SITES — RENDERING CONSOLE',
];

export default function Boot({ onDone }: { onDone: () => void }) {
  const [step, setStep] = useState(0);
  const [out, setOut] = useState(false);

  useEffect(() => {
    const iv = setInterval(() => setStep((s) => Math.min(s + 1, LINES.length)), 420);
    const t1 = setTimeout(() => setOut(true), 2100);
    const t2 = setTimeout(onDone, 2650);
    return () => { clearInterval(iv); clearTimeout(t1); clearTimeout(t2); };
  }, [onDone]);

  return (
    <div className={cn('fixed inset-0 z-[100] flex items-center justify-center bg-ink transition-all duration-500', out && 'pointer-events-none opacity-0')}>
      <div className="tex-grid absolute inset-0 opacity-60" />
      <div className="relative flex w-[min(560px,88vw)] flex-col items-center gap-8">
        <div className="relative h-40 w-40">
          <div className="absolute inset-0 rounded-full border border-ember/25" />
          <div className="absolute inset-3 rounded-full border border-ember/20" />
          <div className="absolute inset-6 rounded-full border border-ember/15" />
          <div className="radar absolute inset-0 rounded-full" />
          <div className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-flare" />
          {[...Array(5)].map((_, i) => (
            <span key={i} className="absolute h-1 w-1 rounded-full bg-ember"
              style={{ left: `${22 + i * 13}%`, top: `${30 + (i % 3) * 17}%`, boxShadow: '0 0 8px #ff6a1f', animation: `blink ${1 + i * 0.4}s steps(1) infinite` }} />
          ))}
        </div>
        <div className="w-full space-y-2 font-mono text-[10px] uppercase tracking-[0.22em] text-smoke">
          {LINES.slice(0, step).map((l) => (
            <p key={l} className="rv on flex items-center gap-2">
              <span className="text-ember">▸</span><span>{l}</span>
              <span className="ml-auto text-flare/80">OK</span>
            </p>
          ))}
        </div>
        <div className="h-px w-full overflow-hidden rounded bg-white/10">
          <div className="h-full bg-gradient-to-r from-ember to-flare" style={{ animation: 'bootBar 1.9s cubic-bezier(.22,1,.36,1) both' }} />
        </div>
        <p className="font-mono text-[10px] tracking-[0.4em] text-smoke/60 uppercase">Burn Signal · v2026.10</p>
      </div>
    </div>
  );
}
