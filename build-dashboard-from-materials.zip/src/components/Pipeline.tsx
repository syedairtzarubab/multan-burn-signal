import { useState } from 'react';
import {
  Satellite, Filter, Scissors, Database, Folder, FolderOpen, FileText, FileSpreadsheet,
  File as FileIcon, ExternalLink, ChevronRight, Workflow, Archive, Map as MapIcon,
} from 'lucide-react';
import { DRIVE_TREE, type DriveNode } from '../data/fires';
import { SectionHead, Corner, Chip } from './ui';
import { cn } from '../utils/cn';

const STEPS = [
  {
    icon: Satellite,
    title: 'Acquire',
    body: 'NASA FIRMS download-manager bundles for VIIRS S-NPP (SV-C2), NOAA-20 (J1V-C2), NOAA-21 (J2V-C2) + MODIS C6.1, Oct 1 – Nov 29 2025, plus periodic 2026 NRT pulls.',
    tag: '01_Raw_FIRMS',
  },
  {
    icon: Filter,
    title: 'Filter',
    body: 'Drop MODIS in favour of 375 m VIIRS; keep type-0 presumed-vegetation fires; confidence nominal/high only — removing industrial stacks and static heat sources.',
    tag: 'conf ≥ n · type 0',
  },
  {
    icon: Scissors,
    title: 'Clip',
    body: 'Spatial clip inside QGIS against the GADM-derived Multan district polygon (PK622, 3,648 km²) — 389 analysis-grade detections survive inside the boundary.',
    tag: 'Capstone Project.qgz',
  },
  {
    icon: Database,
    title: 'Publish',
    body: 'GeoPackages for the master project, slim CSVs for Google My Maps public layers, and this console as the proposed EPCCD early-warning front-end.',
    tag: '03_Cleaned',
  },
];

function Node({ node, depth = 0 }: { node: DriveNode; depth?: number }) {
  const [open, setOpen] = useState(depth < 2);
  const isFolder = node.type === 'folder';
  const href = node.id ? `https://drive.google.com/${isFolder ? 'drive/folders' : 'file/d'}/${node.id}` : undefined;
  const Icon = isFolder ? (open ? FolderOpen : Folder) : node.name.endsWith('.csv') || node.name.endsWith('.kml') ? FileSpreadsheet : node.name.endsWith('.docx') || node.name.endsWith('.pdf') ? FileText : FileIcon;

  return (
    <div>
      <button
        onClick={() => (isFolder ? setOpen(!open) : href && window.open(href, '_blank'))}
        className={cn('group flex w-full items-center gap-2.5 rounded-md px-2.5 py-[7px] text-left font-mono text-[11px] transition-colors hover:bg-white/5')}
        style={{ paddingLeft: `${depth * 20 + 10}px` }}
      >
        {isFolder && <ChevronRight size={11} className={cn('shrink-0 text-smoke/50 transition-transform', open && 'rotate-90')} />}
        {!isFolder && <span className="w-[11px] shrink-0" />}
        <Icon size={13} className={cn('shrink-0', isFolder ? 'text-flare/80' : 'text-ember/70')} />
        <span className={cn('truncate tracking-[0.04em]', isFolder ? 'text-ash' : 'text-smoke group-hover:text-ash')}>{node.name}</span>
        {node.note && <span className="ml-2 hidden truncate text-[9.5px] tracking-[0.1em] text-smoke/50 md:inline">· {node.note}</span>}
        <span className="ml-auto flex shrink-0 items-center gap-3 pl-3">
          {node.size && <span className="text-[10px] text-smoke/60">{node.size}</span>}
          <span className="w-9 text-right text-[10px] text-smoke/40">{node.modified}</span>
          {href && !isFolder && <ExternalLink size={10} className="text-smoke/40 opacity-0 transition-opacity group-hover:opacity-100" />}
        </span>
      </button>
      {isFolder && open && node.children?.map((c) => <Node key={c.name} node={c} depth={depth + 1} />)}
    </div>
  );
}

export default function Pipeline() {
  return (
    <section id="pipeline" className="relative border-t border-white/8 bg-panel/40">
      <div className="mx-auto max-w-[1500px] px-5 py-24 md:px-8 md:py-32">
        <SectionHead
          no="04"
          kicker="From orbit to operations"
          title={<>The pipeline that turns raw pixels<br /><span className="text-smoke">into a district early-warning layer.</span></>}
          right={<Chip>mixed-methods · GIS × policy</Chip>}
        />

        {/* flow */}
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {STEPS.map((s, i) => (
            <div key={s.title} className={`rv rv-d${i} group relative`}>
              <div className="glass relative h-full overflow-hidden rounded-2xl p-6 transition-colors hover:border-ember/30">
                <Corner />
                {i < STEPS.length - 1 && (
                  <ChevronRight size={16} className="absolute -right-3 top-1/2 z-10 hidden -translate-y-1/2 text-ember/60 xl:block" />
                )}
                <div className="flex items-center justify-between">
                  <span className="grid h-11 w-11 place-items-center rounded-lg border border-ember/40 bg-ember/10 text-ember transition-all group-hover:bg-ember/20 group-hover:text-flare">
                    <s.icon size={18} />
                  </span>
                  <span className="num font-mono text-[10px] tracking-[0.2em] text-smoke/50">STEP {i + 1}</span>
                </div>
                <p className="mt-5 text-lg font-medium text-ash">{s.title}</p>
                <p className="mt-2 text-[12.5px] leading-relaxed text-smoke">{s.body}</p>
                <p className="mt-4 inline-block rounded border border-white/10 bg-ink/60 px-2 py-1 font-mono text-[9px] tracking-[0.14em] text-flare/80">{s.tag}</p>
              </div>
            </div>
          ))}
        </div>

        {/* data vault */}
        <div className="mt-14 grid gap-6 lg:grid-cols-12">
          <div className="rv lg:col-span-4">
            <div className="flex h-full flex-col justify-between gap-8">
              <div>
                <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-smoke"><Archive size={12} className="text-ember" /> Source vault</p>
                <h3 className="mt-4 text-2xl font-medium leading-snug tracking-tight text-ash md:text-3xl">
                  Every artefact here exists in the capstone Drive —<span className="text-smoke"> names, sizes and dates intact.</span>
                </h3>
                <p className="mt-4 text-[13px] leading-relaxed text-smoke">
                  This console was refreshed from the shared folder end-to-end: FIRMS archives, the COD-AB boundary,
                  the authoritative 389-point 2025 series, the updated 11-point NRT set, field logs and targets,
                  the QGIS project, final 14-page report, presentation, My Maps links and packaged deliverables.
                </p>
              </div>
              <div className="space-y-2.5">
                {([
                  [Folder, '4 instrument bundles + 2026 NRT', 'raw acquisition archive'],
                  [Workflow, 'QGIS .qgz master project', 'clipping & cartography'],
                  [MapIcon, 'Google My Maps layer', 'public reference map'],
                ] as [typeof Folder, string, string][]).map(([Icon, t, s]) => (
                  <div key={t} className="flex items-center gap-3 rounded-lg border border-white/8 bg-panel/60 px-4 py-3">
                    <Icon size={15} className="shrink-0 text-flare" />
                    <div>
                      <p className="text-[12.5px] text-ash/90">{t}</p>
                      <p className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-smoke/60">{s}</p>
                    </div>
                  </div>
                ))}
                <a href="https://drive.google.com/drive/folders/1w6TMtdMhzgBU7cgEfS8QQZdf7jrJpuU2" target="_blank" rel="noreferrer"
                  className="group inline-flex items-center gap-2.5 rounded-full bg-ember px-5 py-3 font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-ink transition-all hover:bg-flare">
                  Open the source Drive <ExternalLink size={12} className="transition-transform group-hover:translate-x-0.5" />
                </a>
              </div>
            </div>
          </div>

          <div className="rv rv-d1 lg:col-span-8">
            <div className="glass relative overflow-hidden rounded-2xl">
              <Corner />
              <div className="flex items-center justify-between border-b border-white/8 bg-ink/60 px-5 py-3">
                <p className="flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.22em] text-smoke">
                  <span className="flex gap-1.5">
                    <span className="h-2 w-2 rounded-full bg-rose/70" /><span className="h-2 w-2 rounded-full bg-flare/70" /><span className="h-2 w-2 rounded-full bg-emerald-400/70" />
                  </span>
                  gdrive://Capstone Project — verified inventory
                </p>
                <span className="font-mono text-[9.5px] tracking-[0.14em] text-smoke/50">scanned 2026-10-06</span>
              </div>
              <div className="max-h-[560px] overflow-y-auto p-3">
                {DRIVE_TREE.map((n) => <Node key={n.name} node={n} />)}
              </div>
              <div className="border-t border-white/8 bg-panel px-5 py-3">
                <p className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-smoke/60">
                  7 folders · final report + presentation + fieldwork + analysis layers · refreshed 8 Oct 2026
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
