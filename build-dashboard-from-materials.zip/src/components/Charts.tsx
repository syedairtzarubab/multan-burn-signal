import { useMemo } from 'react';
import { Gauge, ShieldCheck, SatelliteDish, TrendingUp, Trophy } from 'lucide-react';
import { OVERPASS, makeDaily, satName, type DayCell, type Fire } from '../data/fires';
import { fireStats, useOfficialFires } from '../data/official';
import { SectionHead, Corner } from './ui';
import { SAT_COLOR } from './MapCore';

const Card = ({ title, icon, children, className = '' }: { title: string; icon: React.ReactNode; children: React.ReactNode; className?: string }) => (
  <div className={`glass relative overflow-hidden rounded-2xl p-6 ${className}`}>
    <Corner />
    <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-smoke">{icon}{title}</p>
    <div className="mt-5">{children}</div>
  </div>
);

/* ── FRP histogram ── */
function FrpHistogram({ fires }: { fires: Fire[] }) {
  const buckets = useMemo(() => {
    const edges = [0, 2, 4, 6, 8, 10, 12, 16, 20, 26, 40];
    const c = edges.slice(0, -1).map(() => 0);
    for (const f of fires) {
      for (let i = 0; i < edges.length - 1; i++) if (f.frp >= edges[i] && f.frp < edges[i + 1]) { c[i]++; break; }
    }
    return edges.slice(0, -1).map((e, i) => ({ label: `${e}`, count: c[i] }));
  }, [fires]);
  const stats = fireStats(fires);
  const max = Math.max(...buckets.map((b) => b.count));
  const H = 190;
  return (
    <div>
      <div className="flex items-end gap-[5px]" style={{ height: H }}>
        {buckets.map((b, i) => (
          <div key={b.label + i} className="group relative flex-1">
            <div className="absolute -top-7 left-1/2 -translate-x-1/2 whitespace-nowrap rounded border border-white/10 bg-ink px-1.5 py-0.5 font-mono text-[9px] text-flare opacity-0 transition-opacity group-hover:opacity-100">{b.count}</div>
            <div className="w-full rounded-t-sm bg-gradient-to-t from-ember/30 to-flare/90 transition-all duration-500 group-hover:to-flare" style={{ height: Math.max(3, (b.count / max) * (H - 4)) }} />
          </div>
        ))}
      </div>
      <div className="mt-2 flex justify-between font-mono text-[8.5px] tracking-[0.1em] text-smoke/70">
        <span>0 MW</span><span>FRP bucket edges →</span><span>40 MW</span>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-3 border-t border-white/8 pt-4">
        {[['Median', stats.median.toFixed(1)], ['Mean', stats.mean.toFixed(1)], ['Max', stats.max.toFixed(1)]].map(([l, v]) => (
          <div key={l}>
            <p className="num text-xl font-semibold text-ash">{v}<span className="ml-1 text-[10px] text-smoke">MW</span></p>
            <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-smoke">{l}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── confidence donut ── */
function ConfidenceDonut({ fires }: { fires: Fire[] }) {
  const total = fires.length;
  const n = fires.filter((f) => f.conf === 'n').length;
  const h = fires.filter((f) => f.conf === 'h').length;
  const pn = n / total, ph = h / total;
  const R = 56, C = 2 * Math.PI * R;
  const arcs = [
    { frac: pn, color: '#ffb020', off: 0, label: 'nominal', count: n },
    { frac: ph, color: '#ff4d5e', off: pn, label: 'high', count: h },
  ];
  return (
    <div className="flex items-center gap-6">
      <svg viewBox="0 0 140 140" className="h-32 w-32 -rotate-90">
        <circle cx="70" cy="70" r={R} fill="none" stroke="#ffffff10" strokeWidth="15" />
        {arcs.map((a) => (
          <circle key={a.label} cx="70" cy="70" r={R} fill="none" stroke={a.color} strokeWidth="15"
            strokeDasharray={`${a.frac * C} ${C}`} strokeDashoffset={-a.off * C} strokeLinecap="butt" />
        ))}
        <text x="70" y="66" textAnchor="middle" fill="#e8e4db" fontSize="19" fontWeight="600" fontFamily="JetBrains Mono" transform="rotate(90 70 70)">{(pn * 100).toFixed(1)}%</text>
        <text x="70" y="84" textAnchor="middle" fill="#8b93a1" fontSize="8.5" letterSpacing="2" fontFamily="JetBrains Mono" transform="rotate(90 70 70)">NOMINAL</text>
      </svg>
      <div className="space-y-3">
        {arcs.map((a) => (
          <div key={a.label} className="flex items-center gap-2.5">
            <span className="h-2.5 w-2.5 rounded-sm" style={{ background: a.color }} />
            <span className="text-[12px] text-ash/90 capitalize">{a.label}</span>
            <span className="num font-mono text-[11px] text-smoke">{a.count} · {(a.frac * 100).toFixed(1)}%</span>
          </div>
        ))}
        <p className="max-w-44 border-t border-white/8 pt-3 text-[11px] leading-relaxed text-smoke/80">
          The baseline analysis retains nominal/high detections; the 2026 field target list separately flags one low-confidence NRT point.
        </p>
      </div>
    </div>
  );
}

/* ── overpass timing (verified rows) ── */
function Overpass() {
  const total = OVERPASS.reduce((s, [, v]) => s + v, 0);
  return (
    <div className="space-y-4">
      {OVERPASS.map(([lbl, v]) => (
        <div key={lbl}>
          <div className="mb-1.5 flex justify-between font-mono text-[10px] tracking-[0.12em]">
            <span className="text-ash/90">{lbl} UTC</span>
            <span className="text-smoke">{v} obs · {((v / total) * 100).toFixed(0)}%</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-white/6">
            <div className="h-full rounded-full bg-gradient-to-r from-ember to-flare transition-all duration-700" style={{ width: `${(v / total) * 100}%` }} />
          </div>
        </div>
      ))}
      <p className="border-t border-white/8 pt-3 text-[11px] leading-relaxed text-smoke/80">
        Sample of verified acquisition times — VIIRS sun-synchronous afternoon overpasses (≈12:00–14:30 PKT) mean
        the dashboard reflects <span className="text-ash/90">daytime burning only</span>; overnight stubble fires
        between passes can slip through unlogged. Night detections (daynight=N) appear in raw MODIS bundles.
      </p>
    </div>
  );
}

/* ── weekly tempo ── */
function Weekly({ daily }: { daily: DayCell[] }) {
  const weeks = useMemo(() => {
    const out: { label: string; v: number; t: number }[] = [];
    for (let w = 0; w < 9; w++) {
      const seg = daily.slice(w * 7, w * 7 + 7);
      const t = seg.reduce((s, d) => s + d.total, 0);
      out.push({ label: `${seg[0].date.slice(5)}`, v: t, t });
    }
    return out;
  }, [daily]);
  const max = Math.max(...weeks.map((w) => w.t));
  const H = 170;
  return (
    <div>
      <div className="flex items-end gap-2.5" style={{ height: H }}>
        {weeks.map((w) => (
          <div key={w.label} className="group relative flex-1">
            <div className="absolute -top-7 left-1/2 -translate-x-1/2 whitespace-nowrap rounded border border-white/10 bg-ink px-1.5 py-0.5 font-mono text-[9px] text-flare opacity-0 transition-opacity group-hover:opacity-100">{w.t}</div>
            <div className="w-full rounded-t-md border border-ember/25 bg-[repeating-linear-gradient(45deg,rgba(255,106,31,.22)_0_2px,transparent_2px_6px)]" style={{ height: Math.max(4, (w.t / max) * (H - 4)) }} />
            <div className="absolute bottom-0 w-full rounded-t-md bg-gradient-to-t from-ember/60 to-flare" style={{ height: Math.max(0, (w.v / max) * (H - 4)) }} />
          </div>
        ))}
      </div>
      <div className="mt-2 flex gap-2.5">
        {weeks.map((w, i) => (
          <div key={i} className="flex-1 text-center font-mono text-[8.5px] tracking-[0.06em] text-smoke/60">{w.label}</div>
        ))}
      </div>
      <p className="mt-4 border-t border-white/8 pt-3 font-mono text-[9px] uppercase tracking-[0.14em] text-smoke/70">
        Weekly totals · final report peak: 15–21 Oct · 95 detections (23 above 10 MW)
      </p>
    </div>
  );
}

/* ── largest events ── */
function TopEvents({ fires }: { fires: Fire[] }) {
  const topEvents = useMemo(() => [...fires].sort((a, b) => b.frp - a.frp).slice(0, 8), [fires]);
  const max = topEvents[0]?.frp ?? 1;
  return (
    <div className="space-y-3">
      {topEvents.map((f, i) => (
        <div key={i} className="group flex items-center gap-3">
          <span className="num w-5 font-mono text-[11px] text-smoke/60">{String(i + 1).padStart(2, '0')}</span>
          <div className="relative h-6 flex-1 overflow-hidden rounded bg-white/4">
            <div className="flex h-full items-center rounded px-2 transition-all duration-700"
              style={{ width: `${(f.frp / max) * 100}%`, background: `linear-gradient(90deg, ${SAT_COLOR[f.sat]}22, ${SAT_COLOR[f.sat]}cc)` }}>
              <span className="num whitespace-nowrap font-mono text-[9.5px] text-ink/90 font-bold">{f.frp.toFixed(1)}</span>
            </div>
          </div>
          <span className="num hidden w-44 shrink-0 font-mono text-[9.5px] text-smoke sm:block">
            {f.date.slice(5)} · {satName(f.sat)} · {f.lat.toFixed(2)}°N {f.lon.toFixed(2)}°E
          </span>
          <span className="num w-16 shrink-0 text-right font-mono text-[10px] text-flare">{f.frp.toFixed(1)} MW</span>
        </div>
      ))}
      <p className="pt-3 border-t border-white/8 font-mono text-[9px] uppercase tracking-[0.14em] text-smoke/70">
        Largest single-pixel FRP events of the season
      </p>
    </div>
  );
}

export default function Charts() {
  const { fires } = useOfficialFires();
  const daily = useMemo(() => makeDaily(fires), [fires]);
  return (
    <section id="analytics" className="relative border-t border-white/8 bg-panel/40">
      <div className="mx-auto max-w-[1500px] px-5 py-24 md:px-8 md:py-32">
        <SectionHead
          no="02"
          kicker="Signal decomposition"
          title={<>The season, taken apart —<br /><span className="text-smoke">intensity, confidence, tempo.</span></>}
        />
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          <div className="rv"><Card title="Fire radiative power distribution" icon={<Gauge size={12} className="text-ember" />} className="h-full"><FrpHistogram fires={fires} /></Card></div>
          <div className="rv rv-d1"><Card title="Confidence composition" icon={<ShieldCheck size={12} className="text-ember" />} className="h-full"><ConfidenceDonut fires={fires} /></Card></div>
          <div className="rv rv-d2"><Card title="Overpass timing · verified" icon={<SatelliteDish size={12} className="text-ember" />} className="h-full"><Overpass /></Card></div>
          <div className="rv md:col-span-2 xl:col-span-2"><Card title="Weekly tempo" icon={<TrendingUp size={12} className="text-ember" />} className="h-full"><Weekly daily={daily} /></Card></div>
          <div className="rv rv-d1"><Card title="Largest events" icon={<Trophy size={12} className="text-ember" />} className="h-full"><TopEvents fires={fires} /></Card></div>
        </div>
      </div>
    </section>
  );
}
