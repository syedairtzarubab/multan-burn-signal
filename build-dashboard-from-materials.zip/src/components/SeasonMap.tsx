import { useEffect, useMemo, useState } from 'react';
import { Play, Pause, RotateCcw, CalendarDays, Flame, Info, Layers, RadioTower } from 'lucide-react';
import { MAP_W, MAP_H, MapCanvasDefs, Graticule, Boundary, PlaceLabels, FirePoints, SAT_COLOR, NRT_COLOR, project } from './MapCore';
import { FIELD_VISITS, NRT_2026, makeDaily, dayIndex, satName, type DayCell, type Fire, type Sat } from '../data/fires';
import { useOfficialFires } from '../data/official';
import { SectionHead, Chip, Corner, LiveChip } from './ui';
import { cn } from '../utils/cn';

const fmtDate = (iso: string) =>
  new Date(iso + 'T00:00:00Z').toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });

function DailyBars({ cursor, onScrub, daily, official }: { cursor: number; onScrub: (i: number) => void; daily: DayCell[]; official: boolean }) {
  const W = 1200, H = 210, PADX = 8;
  const max = Math.max(...daily.map((d) => d.total));
  const bw = (W - PADX * 2) / daily.length;
  const roll = daily.map((_, i) => {
    const s = Math.max(0, i - 6);
    const seg = daily.slice(s, i + 1);
    return seg.reduce((a, b) => a + b.total, 0) / seg.length;
  });
  const path = roll.map((v, i) => `${i === 0 ? 'M' : 'L'}${(PADX + i * bw + bw / 2).toFixed(1)},${(H - 26 - (v / max) * (H - 62)).toFixed(1)}`).join(' ');
  const months: [number, string][] = [[0, 'OCT'], [31, 'NOV']];

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full cursor-crosshair select-none"
      onMouseDown={(e) => {
        const svg = e.currentTarget;
        const move = (ev: MouseEvent) => {
          const r = svg.getBoundingClientRect();
          const x = ((ev.clientX - r.left) / r.width) * W;
          onScrub(Math.max(0, Math.min(daily.length - 1, Math.floor((x - PADX) / bw))));
        };
        move(e.nativeEvent as unknown as MouseEvent);
        const up = () => { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
        window.addEventListener('mousemove', move);
        window.addEventListener('mouseup', up);
      }}>
      <defs>
        <linearGradient id="barV" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" stopColor="#ff6a1f" stopOpacity="0.45" />
          <stop offset="1" stopColor="#ffb020" stopOpacity="0.95" />
        </linearGradient>
        <linearGradient id="rollG" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffb020" /><stop offset="0.55" stopColor="#ff6a1f" /><stop offset="1" stopColor="#ff4d5e" />
        </linearGradient>
        <pattern id="hatchB" width="6" height="6" patternTransform="rotate(45)" patternUnits="userSpaceOnUse">
          <rect width="6" height="6" fill="#ff6a1f" fillOpacity="0.10" />
          <line x1="0" y1="0" x2="0" y2="6" stroke="#ff6a1f" strokeWidth="1.1" strokeOpacity="0.5" />
        </pattern>
      </defs>

      {[0.25, 0.5, 0.75, 1].map((f) => (
        <g key={f}>
          <line x1={PADX} x2={W - PADX} y1={H - 26 - f * (H - 62)} y2={H - 26 - f * (H - 62)} stroke="#ffffff" strokeOpacity="0.05" />
          <text x={PADX + 2} y={H - 30 - f * (H - 62)} fill="#8b93a1" fillOpacity="0.6" fontSize="10" fontFamily="JetBrains Mono">{Math.round(max * f)}</text>
        </g>
      ))}

      {daily.map((d, i) => {
        const h = Math.max(2, (d.total / max) * (H - 62));
        return (
          <rect key={d.date} x={PADX + i * bw + 1.5} y={H - 26 - h} width={bw - 3} height={h}
            fill={d.verified ? 'url(#barV)' : 'url(#hatchB)'}
            stroke={i === cursor ? '#fff' : 'none'} strokeOpacity={i === cursor ? 0.8 : 0}
            opacity={i <= cursor ? 1 : 0.32} className="bar-grow" />
        );
      })}

      <path d={path} fill="none" stroke="url(#rollG)" strokeWidth="2" strokeOpacity="0.9" />

      {months.map(([i, m]) => (
        <text key={m} x={PADX + i * bw} y={H - 8} fill="#8b93a1" fontSize="11" fontWeight="600" letterSpacing="3" fontFamily="JetBrains Mono">{m}</text>
      ))}
      <text x={W - 8} y={18} textAnchor="end" fill="#8b93a1" fontSize="10" letterSpacing="1.5" fontFamily="JetBrains Mono">
        DAILY DETECTIONS · {official ? 'AUTHORITATIVE 389-POINT FIRMS SERIES' : 'LOADING AUTHORITATIVE SERIES'} · line = 7-day mean
      </text>

      <g style={{ transition: 'transform .25s' }} transform={`translate(${PADX + cursor * bw + bw / 2},0)`}>
        <line y1="8" y2={H - 26} stroke="#52e5ff" strokeWidth="1.4" strokeOpacity="0.9" />
        <circle cy="8" r="4" fill="#52e5ff" />
      </g>
    </svg>
  );
}

export default function SeasonMap() {
  const { fires, official } = useOfficialFires();
  const daily = useMemo(() => makeDaily(fires), [fires]);
  const [cursor, setCursor] = useState(59);
  const [playing, setPlaying] = useState(false);
  const [dayMode, setDayMode] = useState(false);
  const [sats, setSats] = useState<Set<Sat>>(new Set(['SNPP', 'N20', 'N21']));
  const [showNrt, setShowNrt] = useState(true);
  const [hovered, setHovered] = useState<Fire | null>(null);

  useEffect(() => {
    if (!playing) return;
    const iv = setInterval(() => {
      setCursor((c) => {
        if (c >= daily.length - 1) { setPlaying(false); return c; }
        return c + 1;
      });
    }, 430);
    return () => clearInterval(iv);
  }, [playing, daily.length]);

  const satFilter = useMemo(() => (f: Fire) => sats.has(f.sat), [sats]);
  const shown = useMemo(() => {
    const within = (f: Fire) => {
      const di = dayIndex(f.date);
      return dayMode ? di === cursor : di <= cursor;
    };
    return fires.filter((f) => satFilter(f) && within(f));
  }, [cursor, dayMode, satFilter, fires]);

  const recent = useMemo(() => shown.filter((f) => dayIndex(f.date) > cursor - 7), [shown, cursor]);
  const older = useMemo(() => shown.filter((f) => dayIndex(f.date) <= cursor - 7), [shown, cursor]);

  const dateStr = daily[cursor].date;
  const dayCell = daily[cursor];
  const cum = daily.slice(0, cursor + 1).reduce((s, d) => s + d.total, 0);

  const RING = 2 * Math.PI * 24;

  return (
    <section id="map" className="relative mx-auto max-w-[1500px] px-5 py-24 md:px-8 md:py-32">
      <SectionHead
        no="01"
        kicker="Season playback · 2025 baseline"
        title={<>Sixty days of ignition,<br /><span className="text-smoke">played back frame by frame.</span></>}
        right={<LiveChip label="2026 NRT overlay available" />}
      />

      <div className="grid gap-6 lg:grid-cols-12">
        {/* MAP */}
        <div className="rv relative lg:col-span-7">
          <div className="glass edge-glow relative overflow-hidden rounded-2xl">
            <Corner />
            <div className="flex items-center justify-between border-b border-white/8 px-5 py-3">
              <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-smoke">
                Sector view · Multan District PK622 <span className="text-ember">· {fmtDate(dateStr)}</span>
              </p>
              <div className="flex items-center gap-2">
                {(['SNPP', 'N20', 'N21'] as Sat[]).map((s) => (
                  <button key={s}
                    onClick={() => setSats((prev) => { const n = new Set(prev); n.has(s) ? n.delete(s) : n.add(s); return n; })}
                    className={cn('rounded-full border px-2.5 py-1 font-mono text-[9.5px] tracking-[0.14em] transition-all',
                      sats.has(s) ? 'border-white/20 text-ash' : 'border-white/8 text-smoke/40 line-through')}
                    style={sats.has(s) ? { borderColor: SAT_COLOR[s] + '66', color: SAT_COLOR[s] } : undefined}>
                    {satName(s).toUpperCase()}
                  </button>
                ))}
                <button onClick={() => setShowNrt(!showNrt)}
                  className={cn('rounded-full border px-2.5 py-1 font-mono text-[9.5px] tracking-[0.14em] transition-all',
                    showNrt ? 'border-ice/60 text-ice' : 'border-white/8 text-smoke/40 line-through')}>
                  NRT ’26
                </button>
              </div>
            </div>

            <div className="relative bg-[#080a0e]">
              <svg viewBox={`0 0 ${MAP_W} ${MAP_H}`} className="mx-auto max-h-[76vh] w-full" preserveAspectRatio="xMidYMid meet">
                <MapCanvasDefs />
                <Graticule />
                <Boundary strong />
                <PlaceLabels />
                <FirePoints fires={older} dim glow={false} filter={undefined} onHover={setHovered} animate={false} />
                <FirePoints fires={recent} glow onHover={setHovered} animate={false} />
                {showNrt && <FirePoints fires={NRT_2026} glow onHover={setHovered} />}
                {showNrt && FIELD_VISITS.map((site) => {
                  const [x, y] = project(site.lon, site.lat);
                  return (
                    <g key={site.id} transform={`translate(${x},${y})`}>
                      <circle r="12" fill="#0b0e13" stroke={site.id === 'B' ? '#ffb020' : '#ff4d5e'} strokeWidth="2" />
                      <path d="M-5 0H5M0-5V5" stroke={site.id === 'B' ? '#ffb020' : '#ff4d5e'} strokeWidth="1.5" />
                      <text x="16" y="4" fill="#e8e4db" fontSize="10" fontWeight="600" fontFamily="JetBrains Mono">FIELD {site.id}</text>
                    </g>
                  );
                })}

                {/* hover tooltip */}
                {hovered && (() => {
                  const [x, y] = project(hovered.lon, hovered.lat);
                  return (
                    <g transform={`translate(${Math.min(Math.max(x + 14, 10), MAP_W - 228)},${Math.max(y - 86, 10)})`} pointerEvents="none">
                      <rect width="218" height="78" rx="8" fill="#0b0e13" fillOpacity="0.94" stroke={hovered.src === 'nrt' ? NRT_COLOR : SAT_COLOR[hovered.sat]} strokeOpacity="0.5" />
                      <text x="12" y="20" fill="#e8e4db" fontSize="11.5" fontWeight="600" fontFamily="JetBrains Mono">
                        {fmtDate(hovered.date)} · {satName(hovered.sat)}
                      </text>
                      <text x="12" y="38" fill="#8b93a1" fontSize="10.5" fontFamily="JetBrains Mono">
                        FRP {hovered.frp.toFixed(2)} MW · conf {hovered.conf === 'h' ? 'high' : hovered.conf === 'n' ? 'nominal' : 'low'}
                      </text>
                      <text x="12" y="53" fill="#8b93a1" fontSize="10.5" fontFamily="JetBrains Mono">
                        {hovered.lat.toFixed(4)}°N, {hovered.lon.toFixed(4)}°E
                      </text>
                      <text x="12" y="68" fill={hovered.src === 'firms' ? '#ffb020' : hovered.src === 'nrt' ? '#52e5ff' : '#8b93a1'} fontSize="9.5" letterSpacing="1.5" fontFamily="JetBrains Mono">
                        {hovered.src === 'firms' ? 'VERIFIED FIRMS ROW' : hovered.src === 'nrt' ? 'LIVE NRT 2026' : 'SEASON RECONSTRUCTION'}
                      </text>
                    </g>
                  );
                })()}
              </svg>

              {/* inspector */}
              <div className="pointer-events-none absolute left-4 top-4 space-y-1.5">
                <p className="glass inline-flex items-center gap-2 rounded-md px-3 py-1.5 font-mono text-[10px] tracking-[0.18em] text-flare">
                  <CalendarDays size={11} /> {fmtDate(dateStr)}
                </p>
                <p className="glass block w-fit rounded-md px-3 py-1.5 font-mono text-[10px] tracking-[0.14em] text-smoke">
                  IGNITIONS ≤ DATE · <span className="text-ash num">{cum}</span> / 389
                </p>
                <p className="glass block w-fit rounded-md px-3 py-1.5 font-mono text-[10px] tracking-[0.14em] text-smoke">
                  THIS DAY · <span className="text-ash num">{dayCell.total}</span> FIRES · <span className="text-flare">{dayCell.frp.toFixed(0)} MW</span>
                </p>
              </div>

              {showNrt && (
                <p className="glass absolute right-4 top-4 inline-flex items-center gap-2 rounded-md px-3 py-1.5 font-mono text-[10px] tracking-[0.16em] text-ice">
                  <RadioTower size={11} /> 11 NRT · 2 FIELD SITES · OCT ’26
                </p>
              )}
            </div>

            {/* playback deck */}
            <div className="flex flex-wrap items-center gap-4 border-t border-white/8 bg-panel px-5 py-4">
              <button
                onClick={() => { if (cursor >= daily.length - 1 && !playing) setCursor(0); setPlaying(!playing); }}
                className="relative grid h-14 w-14 shrink-0 place-items-center rounded-full text-ink transition-transform hover:scale-105"
                aria-label={playing ? 'pause' : 'play'}>
                <svg className="absolute inset-0 -rotate-90" viewBox="0 0 52 52">
                  <circle cx="26" cy="26" r="24" fill="#ff6a1f" />
                  <circle cx="26" cy="26" r="24" fill="none" stroke="#06080b" strokeWidth="3" strokeDasharray={RING} strokeDashoffset={RING * (1 - cursor / (daily.length - 1))} strokeLinecap="round" />
                </svg>
                {playing ? <Pause size={18} className="relative" /> : <Play size={18} className="relative ml-0.5" />}
              </button>

              <div className="min-w-44 flex-1">
                <div className="mb-1.5 flex justify-between font-mono text-[9px] uppercase tracking-[0.2em] text-smoke">
                  <span>Oct 01</span><span className="text-flare">day {cursor + 1} / 60</span><span>Nov 29</span>
                </div>
                <input type="range" min={0} max={daily.length - 1} value={cursor}
                  onChange={(e) => { setPlaying(false); setCursor(+e.target.value); }}
                  className="scrub w-full" style={{ ['--fill' as string]: `${(cursor / (daily.length - 1)) * 100}%` }} />
              </div>

              <div className="flex items-center gap-2">
                <button onClick={() => setDayMode(!dayMode)}
                  className={cn('inline-flex items-center gap-2 rounded-full border px-3.5 py-2 font-mono text-[9.5px] uppercase tracking-[0.16em] transition-all',
                    dayMode ? 'border-flare/70 bg-flare/10 text-flare' : 'border-white/12 text-smoke hover:text-ash')}>
                  <Layers size={11} /> {dayMode ? 'single day' : 'cumulative'}
                </button>
                <button onClick={() => { setPlaying(false); setCursor(0); }}
                  className="grid h-9 w-9 place-items-center rounded-full border border-white/12 text-smoke transition-colors hover:text-flare" aria-label="reset">
                  <RotateCcw size={13} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* SIDE DECK */}
        <div className="flex flex-col gap-6 lg:col-span-5">
          <div className="rv rv-d1 glass relative rounded-2xl p-6">
            <Corner />
            <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-smoke">Season signature</p>
            <div className="mt-4 grid grid-cols-3 gap-4">
              {[
                [String(cum), 'shown to date', 'text-flare'],
                [String(dayCell.total), 'this day', 'text-ash'],
                [`${dayCell.frp.toFixed(0)}`, 'MW this day', 'text-ember'],
              ].map(([v, l, c]) => (
                <div key={l} className="border-l border-white/10 pl-3">
                  <p className={cn('num text-3xl font-semibold', c)}>{v}</p>
                  <p className="mt-1 font-mono text-[9px] uppercase tracking-[0.16em] text-smoke">{l}</p>
                </div>
              ))}
            </div>
            <div className="mt-5 space-y-2.5 border-t border-white/8 pt-4">
              {(['SNPP', 'N20', 'N21'] as Sat[]).map((s) => {
                const n = fires.filter((f) => f.sat === s).length;
                return (
                  <div key={s} className="flex items-center gap-3">
                    <span className="h-2 w-2 rounded-full" style={{ background: SAT_COLOR[s], boxShadow: `0 0 8px ${SAT_COLOR[s]}` }} />
                    <span className="w-24 font-mono text-[10px] tracking-[0.14em] text-smoke">{satName(s).toUpperCase()}</span>
                    <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/6">
                      <div className="h-full rounded-full transition-all duration-700" style={{ width: `${(n / fires.length) * 100}%`, background: SAT_COLOR[s] }} />
                    </div>
                    <span className="num w-10 text-right font-mono text-[10.5px] text-ash">{n}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="rv rv-d2 glass relative rounded-2xl p-6">
            <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-smoke"><Info size={12} className="text-ember" /> Data provenance</p>
            <ul className="mt-4 space-y-3.5 text-[12.5px] leading-relaxed text-smoke">
              <li className="flex gap-3">
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-flare" />
                <span><span className="text-ash">Full 2025 season — authoritative.</span> All 389 points load from the compact public companion dataset generated from <span className="font-mono text-[11px] text-flare/90">FIRMS_2025_Multan_VIIRS.csv</span>.</span>
              </li>
              <li className="flex gap-3">
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full border border-ember bg-ember/20" />
                <span><span className="text-ash">Quality check.</span> The loader validates an exact <span className="text-ash">389 rows</span> before replacing the embedded fallback. Current status: <span className={official ? 'text-emerald-400' : 'text-flare'}>{official ? 'verified and loaded' : 'loading / offline fallback'}</span>.</span>
              </li>
              <li className="flex gap-3">
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-ice" />
                <span><span className="text-ash">Oct 2–5 ’26 — live NRT.</span> All 11 points verbatim from the updated <span className="font-mono text-[11px] text-ice/90">FIRMS_2026_NRT_Multan.csv</span>.</span>
              </li>
            </ul>
          </div>

          <div className="rv rv-d3 relative overflow-hidden rounded-2xl border border-ember/25 bg-gradient-to-br from-ember/12 via-panel to-panel p-6">
            <Flame className="absolute -right-4 -top-4 h-24 w-24 text-ember/10" />
            <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-ember">Field manual note</p>
            <p className="mt-3 text-[13px] leading-relaxed text-ash/85">
              VIIRS sees each 375 m pixel up to twice daily per satellite. Here, a “fire” is a type-0 thermal
              anomaly (presumed vegetation fire) at nominal or high confidence — industrial stacks and static
              heat sources were excluded in QGIS before clipping to the district polygon.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Chip>type = 0</Chip><Chip>conf ≥ nominal</Chip><Chip>clipped: GADM Multan</Chip>
            </div>
          </div>
        </div>
      </div>

      {/* DAILY BARS */}
      <div className="rv glass relative mt-6 overflow-hidden rounded-2xl p-5 md:p-7">
        <Corner />
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-smoke">
            Detections per day · <span className="text-ice">scrub the chart or press play</span>
          </p>
          <div className="flex items-center gap-4 font-mono text-[9.5px] uppercase tracking-[0.14em] text-smoke">
            <span className="flex items-center gap-1.5"><span className="h-2 w-3 rounded-sm bg-gradient-to-t from-ember/50 to-flare" /> official FIRMS rows</span>
            <span className="flex items-center gap-1.5"><span className="h-0.5 w-4 bg-gradient-to-r from-flare to-rose" /> 7-day mean</span>
          </div>
        </div>
        <DailyBars cursor={cursor} daily={daily} official={official} onScrub={(i) => { setPlaying(false); setCursor(i); }} />
      </div>
    </section>
  );
}
