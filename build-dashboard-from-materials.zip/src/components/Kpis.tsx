import { useEffect, useRef, useState } from 'react';
import { Flame, Grid3X3, Gauge, MapPinned, Target, RadioTower } from 'lucide-react';
import { SEASON_TOTAL, PEAK_DAY, NRT_2026, OFFICIAL_SUMMARY } from '../data/fires';
import { fireStats, useOfficialFires } from '../data/official';
import { useCountUp } from './ui';

function Kpi({ icon, value, decimals = 0, suffix, label, sub, accent }: {
  icon: React.ReactNode; value: number; decimals?: number; suffix?: string; label: string; sub: string; accent: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [go, setGo] = useState(false);
  useEffect(() => {
    const io = new IntersectionObserver(([e]) => e.isIntersecting && setGo(true), { threshold: 0.4 });
    if (ref.current) io.observe(ref.current);
    return () => io.disconnect();
  }, []);
  const v = useCountUp(value, { start: go, decimals });
  return (
    <div ref={ref} className="group relative overflow-hidden border-white/8 bg-panel px-5 py-6 transition-colors hover:bg-panel2 md:px-7">
      <div className="absolute -right-6 -top-6 h-20 w-20 rounded-full opacity-20 blur-2xl transition-opacity group-hover:opacity-50" style={{ background: accent }} />
      <div className="flex items-center gap-2 text-smoke" style={{ color: accent }}>{icon}</div>
      <p className="num mt-3 text-4xl font-semibold tracking-tight text-ash md:text-[2.9rem]">
        {v.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}
        {suffix && <span className="ml-1 text-lg text-smoke">{suffix}</span>}
      </p>
      <p className="mt-1.5 text-[12px] font-medium text-ash/85">{label}</p>
      <p className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-smoke/70 mt-0.5">{sub}</p>
    </div>
  );
}

export default function Kpis() {
  const { fires } = useOfficialFires();
  const stats = fireStats(fires);
  return (
    <section className="relative border-y border-white/8 bg-ink">
      <div className="mx-auto grid max-w-[1500px] grid-cols-2 gap-px bg-white/8 md:grid-cols-3 xl:grid-cols-6">
        <Kpi icon={<Flame size={15} />} value={SEASON_TOTAL} label="season detections" sub="Oct 1 → Nov 29 ’25" accent="#ff6a1f" />
        <Kpi icon={<Grid3X3 size={15} />} value={OFFICIAL_SUMMARY.occupiedCells} label="occupied 5 km cells" sub="top 10 hold 56%" accent="#ffb020" />
        <Kpi icon={<Gauge size={15} />} value={stats.max} decimals={2} suffix="MW" label="peak single-pixel FRP" sub="2025 maximum" accent="#ff4d5e" />
        <Kpi icon={<Target size={15} />} value={OFFICIAL_SUMMARY.highIntensity2025} label="high-intensity pixels" sub="FRP > 10 MW" accent="#52e5ff" />
        <Kpi icon={<MapPinned size={15} />} value={OFFICIAL_SUMMARY.fieldSites} label="field sites visited" sub="7 Oct · ~70 km" accent="#ff8f5f" />
        <Kpi icon={<RadioTower size={15} />} value={NRT_2026.length} label="live NRT alerts" sub="2–5 Oct 2026" accent="#34d399" />
      </div>

      {/* 2026 season opening — verbatim NRT rows */}
      <div className="border-t border-white/8 bg-panel/50">
        <div className="mx-auto flex max-w-[1500px] flex-wrap items-center gap-x-8 gap-y-4 px-5 py-4 md:px-8">
          <p className="flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.24em] text-ice">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute h-full w-full animate-ping rounded-full bg-ice opacity-70" />
              <span className="relative h-1.5 w-1.5 rounded-full bg-ice" />
            </span>
            First smoke ’26 · NRT feed
          </p>
          <div className="flex flex-wrap items-center gap-2">
            {[...NRT_2026].sort((a, b) => a.date.localeCompare(b.date)).map((f, i) => (
              <span key={i} className="num inline-flex items-center gap-2 rounded-md border border-ice/25 bg-ice/[0.06] px-2.5 py-1.5 font-mono text-[9.5px] tracking-[0.06em] text-smoke">
                <span className="text-ice">{f.date.slice(5)} ’26</span>
                {f.lat.toFixed(2)}°N {f.lon.toFixed(2)}°E · {f.frp.toFixed(2)} MW · {f.sat === 'N20' ? 'NOAA-20' : 'NOAA-21'}
                {f.conf === 'l' && <span className="text-rose/90">low-conf</span>}
              </span>
            ))}
          </div>
          <p className="ml-auto font-mono text-[9.5px] uppercase tracking-[0.16em] text-smoke/60">
            11 detections by Oct 5 · all daytime · max 7.3 MW
          </p>
        </div>
      </div>
    </section>
  );
}

export function PeakNote() {
  return <span className="num">{PEAK_DAY.date}</span>;
}
