import { useEffect, useRef, useState, type ReactNode } from 'react';
import { cn } from '../utils/cn';

/* IntersectionObserver reveal — attach once to document (waits for `dep` to be truthy) */
export function useRevealRoot(dep: unknown = null) {
  useEffect(() => {
    if (dep === false) return;
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && e.target.classList.add('on')),
      { threshold: 0.12, rootMargin: '0px 0px -6% 0px' }
    );
    document.querySelectorAll('.rv:not(.on)').forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [dep]);
}

export function useCountUp(target: number, opts: { duration?: number; decimals?: number; start?: boolean } = {}) {
  const { duration = 1600, decimals = 0, start = true } = opts;
  const [val, setVal] = useState(0);
  const ref = useRef<number>(0);
  useEffect(() => {
    if (!start) return;
    const t0 = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / duration);
      const e = 1 - Math.pow(1 - p, 4);
      setVal(+((target * e).toFixed(decimals)));
      if (p < 1) ref.current = requestAnimationFrame(tick);
    };
    ref.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(ref.current!);
  }, [target, start, duration, decimals]);
  return val;
}

export function Kicker({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn('font-mono text-[10px] md:text-[11px] uppercase tracking-[0.32em] text-ember/90', className)}>
      {children}
    </div>
  );
}

export function SectionHead({ no, kicker, title, right }: { no: string; kicker: string; title: ReactNode; right?: ReactNode }) {
  return (
    <div className="rv mb-10 md:mb-14 flex flex-wrap items-end justify-between gap-6 border-b border-white/8 pb-6">
      <div className="flex items-start gap-5">
        <span className="num mt-1 font-mono text-[11px] text-smoke/70">/{no}</span>
        <div>
          <Kicker>{kicker}</Kicker>
          <h2 className="mt-3 max-w-3xl text-3xl md:text-5xl font-medium leading-[1.04] tracking-tight text-ash text-balance">{title}</h2>
        </div>
      </div>
      {right && <div className="pb-1">{right}</div>}
    </div>
  );
}

export function Chip({ children, className, active }: { children: ReactNode; className?: string; active?: boolean }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-[0.16em] transition-colors',
        active ? 'border-ember/60 bg-ember/15 text-flare' : 'border-white/10 bg-white/[0.03] text-smoke',
        className
      )}
    >
      {children}
    </span>
  );
}

export function LiveChip({ label = 'LIVE', className }: { label?: string; className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-2 rounded-full border border-ice/40 bg-ice/10 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.2em] text-ice', className)}>
      <span className="relative flex h-1.5 w-1.5">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-ice opacity-70" />
        <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-ice" />
      </span>
      {label}
    </span>
  );
}

export function Corner({ className }: { className?: string }) {
  return (
    <div aria-hidden className={cn('pointer-events-none absolute inset-0', className)}>
      {['top-0 left-0 border-t border-l', 'top-0 right-0 border-t border-r', 'bottom-0 left-0 border-b border-l', 'bottom-0 right-0 border-b border-r'].map((p) => (
        <span key={p} className={cn('absolute h-3.5 w-3.5 border-ember/70', p)} />
      ))}
    </div>
  );
}
