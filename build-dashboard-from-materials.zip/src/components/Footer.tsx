import { ArrowUp, ExternalLink, Flame } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-white/8 bg-panel/60">
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-56 bg-[radial-gradient(60%_100%_at_50%_120%,rgba(255,106,31,.14),transparent_70%)]" />
      <div className="mx-auto max-w-[1500px] px-5 pb-10 pt-16 md:px-8">
        <div className="flex flex-wrap items-start justify-between gap-10">
          <div className="max-w-md">
            <div className="flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-lg border border-ember/50 bg-ember/10 text-ember"><Flame size={18} /></span>
              <div>
                <p className="text-lg font-semibold tracking-[0.14em] text-ash">BURN SIGNAL</p>
                <p className="font-mono text-[9px] uppercase tracking-[0.26em] text-smoke">Multan District · residue-fire intelligence</p>
              </div>
            </div>
            <p className="mt-5 text-[12.5px] leading-relaxed text-smoke">
              Capstone deliverable — CM Punjab Climate Leadership Development Internship (Phase II) for EPCCD.
              Data: NASA FIRMS VIIRS S-NPP / NOAA-20 / NOAA-21; boundary: GADM-derived Multan PK622;
              season anchor: 389 detections, Oct 1 – Nov 29 2025.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-x-14 gap-y-2 font-mono text-[10.5px] uppercase tracking-[0.16em]">
            <p className="col-span-2 mb-1 text-[9px] tracking-[0.24em] text-smoke/50">Navigate</p>
            {[['Season map', '#map'], ['Analytics', '#analytics'], ['Hotspots', '#hotspots'], ['Pipeline', '#pipeline'], ['Field brief', '#report']].map(([l, h]) => (
              <a key={h} href={h} className="text-smoke transition-colors hover:text-flare">{l}</a>
            ))}
          </div>

          <div className="grid gap-2 font-mono text-[10.5px] uppercase tracking-[0.16em]">
            <p className="mb-1 text-[9px] tracking-[0.24em] text-smoke/50">Sources</p>
            {[
              ['Capstone Drive', 'https://drive.google.com/drive/folders/1w6TMtdMhzgBU7cgEfS8QQZdf7jrJpuU2'],
              ['NASA FIRMS', 'https://firms.modaps.eosdis.nasa.gov'],
              ['FIRMS VIIRS S-NPP / NOAA-20 / 21', 'https://www.earthdata.nasa.gov/learn/find-data/near-real-time/firms'],
            ].map(([l, h]) => (
              <a key={h} href={h} target="_blank" rel="noreferrer" className="group flex items-center gap-1.5 text-smoke transition-colors hover:text-flare">
                {l} <ExternalLink size={10} className="opacity-40 transition-opacity group-hover:opacity-100" />
              </a>
            ))}
          </div>
        </div>

        <div className="mt-14 select-none overflow-hidden border-t border-white/8 pt-8">
          <p className="whitespace-nowrap text-center text-[11.5vw] font-bold leading-none tracking-[-0.02em] text-white/[0.045] md:text-[8.5rem] lg:text-[10rem]">
            SMOKE SEASON
          </p>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-4 border-t border-white/8 pt-6">
          <p className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-smoke/60">
            29.50°N–30.40°N · 70.80°E–71.95°E · 3,648 km² · 2M+ residents exposed
          </p>
          <a href="#top" className="group flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-smoke transition-colors hover:text-flare">
            Back to orbit <ArrowUp size={12} className="transition-transform group-hover:-translate-y-1" />
          </a>
        </div>
      </div>
    </footer>
  );
}
