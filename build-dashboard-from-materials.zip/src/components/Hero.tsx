import { useMemo } from 'react';
import { ArrowDown, ArrowUpRight, Flame, MapPin, Satellite } from 'lucide-react';
import { MAP_W, MAP_H, MapCanvasDefs, Graticule, Boundary, FirePoints, NRT_COLOR } from './MapCore';
import { NRT_2026, satName } from '../data/fires';
import { useOfficialFires } from '../data/official';
import { Chip, LiveChip } from './ui';

const EMBERS = Array.from({ length: 26 }, (_, i) => ({
  left: 4 + ((i * 37) % 92),
  bottom: -3 - (i % 6) * 2,
  size: 2 + (i % 4),
  dur: 9 + (i % 7) * 2.6,
  delay: (i * 1.7) % 12,
  hue: i % 3,
}));

export default function Hero() {
  const { fires } = useOfficialFires();
  const ambient = useMemo(() => fires.filter((f) => f.frp > 12), [fires]);
  const topEvents = useMemo(() => [...fires].sort((a, b) => b.frp - a.frp).slice(0, 8), [fires]);

  const ticker = useMemo(() => {
    const evts = topEvents.slice(0, 6).map(
      (f) => `${f.date} · ${satName(f.sat).toUpperCase()} · ${f.lat.toFixed(3)}°N ${f.lon.toFixed(3)}°E · FRP ${f.frp.toFixed(1)} MW · ${f.conf === 'h' ? 'HIGH' : 'NOMINAL'}`
    );
    const nrt = NRT_2026.slice(0, 3).map((f) => `${f.date} · NRT · ${f.lat.toFixed(3)}°N ${f.lon.toFixed(3)}°E · FRP ${f.frp.toFixed(2)} MW · ${satName(f.sat).toUpperCase()}`);
    return [...evts, 'REPORT ANCHOR — 389 DETECTIONS RETRIEVED · OCT 1 → NOV 29 2025', ...nrt, 'VIIRS 375 m · CONFIDENCE NOMINAL/HIGH · TYPE-0 VEGETATION FIRES ONLY'];
  }, [topEvents]);

  return (
    <section id="top" className="tex-noise relative flex min-h-[100svh] flex-col overflow-hidden">
      {/* backdrop map */}
      <div className="pointer-events-none absolute inset-y-0 right-[-38vw] w-[105vw] opacity-[0.5] sm:right-[-24vw] sm:w-[86vw] md:right-[-12vw] md:w-[72vw] lg:right-[-6vw] lg:w-[58vw] lg:opacity-[0.66]">
        <svg viewBox={`0 0 ${MAP_W} ${MAP_H}`} className="h-full w-full" preserveAspectRatio="xMidYMid meet">
          <MapCanvasDefs />
          <Graticule />
          <Boundary strong />
          <FirePoints fires={ambient} dim glow animate />
          <FirePoints fires={NRT_2026} glow animate />
        </svg>
      </div>
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(100deg,#06080b_22%,rgba(6,8,11,.88)_42%,rgba(6,8,11,.25)_75%,rgba(6,8,11,.55))]" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(90%_70%_at_72%_38%,rgba(255,106,31,.12),transparent_60%)]" />

      {/* rising embers */}
      <div aria-hidden className="pointer-events-none absolute inset-0 hidden md:block">
        {EMBERS.map((e, i) => (
          <span key={i} className="ember"
            style={{
              left: `${e.left}%`, bottom: `${e.bottom}%`, width: e.size, height: e.size,
              background: e.hue === 0 ? '#ffb020' : e.hue === 1 ? '#ff6a1f' : '#ff4d5e',
              boxShadow: `0 0 ${e.size * 3}px ${e.hue === 0 ? '#ffb020' : '#ff6a1f'}`,
              animationDuration: `${e.dur}s`, animationDelay: `${e.delay}s`,
            }} />
        ))}
      </div>

      <div className="scanline" />

      {/* content */}
      <div className="relative z-10 mx-auto flex w-full max-w-[1500px] flex-1 flex-col justify-center px-5 pt-32 pb-40 md:px-8 md:pt-36">
        <div className="rv flex flex-wrap items-center gap-2.5">
          <Chip active><Satellite size={11} /> NASA FIRMS · VIIRS 375 m</Chip>
          <Chip>District Multan · Punjab</Chip>
          <LiveChip label="NRT season live" />
        </div>

        <h1 className="rv rv-d1 mt-7 max-w-5xl text-[13.5vw] font-medium leading-[0.94] tracking-[-0.03em] text-ash sm:text-[11vw] lg:text-[6.8rem]">
          Every field fire,
          <br />
          <span className="bg-gradient-to-r from-flare via-ember to-rose bg-clip-text text-transparent">made visible.</span>
        </h1>

        <p className="rv rv-d2 mt-7 max-w-xl text-[15px] leading-relaxed text-smoke md:text-base">
          A satellite early-warning console for agricultural residue burning in Multan District —
          <span className="text-ash"> 389 VIIRS detections</span> across the Oct–Nov 2025 smoke season,
          clipped to the district boundary, ground-checked at two sites, and streamed into one operational view
          for Punjab's Environment Protection &amp; Climate Change Department.
        </p>

        <div className="rv rv-d3 mt-10 flex flex-wrap items-center gap-4">
          <a href="#map" className="group inline-flex items-center gap-3 rounded-full bg-ember px-6 py-3.5 font-mono text-[11px] font-bold uppercase tracking-[0.2em] text-ink transition-all hover:bg-flare hover:shadow-[0_0_40px_rgba(255,176,32,.35)]">
            <Flame size={14} /> Run the season
            <ArrowDown size={14} className="transition-transform group-hover:translate-y-0.5" />
          </a>
          <a href="#report" className="group inline-flex items-center gap-3 rounded-full border border-white/15 px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-ash transition-all hover:border-flare/60 hover:text-flare">
            Read the field brief <ArrowUpRight size={14} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
        </div>

        <div className="rv rv-d4 mt-14 grid max-w-2xl grid-cols-3 gap-px overflow-hidden rounded-xl border border-white/10 bg-white/10">
          {[
            ['389', 'season detections', 'Oct 1 – Nov 29 ’25'],
            ['375 m', 'pixel resolution', 'VIIRS × 3 satellites'],
            ['11', 'live NRT alerts', 'Oct 2–5 · 2026 season'],
          ].map(([big, l1, l2]) => (
            <div key={l1} className="bg-panel/90 px-4 py-4 md:px-6">
              <p className="num text-2xl font-semibold text-flare md:text-3xl">{big}</p>
              <p className="mt-1 text-[11px] font-medium text-ash/90">{l1}</p>
              <p className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-smoke/70 mt-0.5">{l2}</p>
            </div>
          ))}
        </div>
      </div>

      {/* detection ticker */}
      <div className="relative z-10 border-t border-white/8 bg-ink/80 py-3 backdrop-blur-md">
        <div className="flex items-center">
          <div className="z-10 flex shrink-0 items-center gap-2 border-r border-white/10 bg-ink px-4 font-mono text-[10px] uppercase tracking-[0.24em] text-ember">
            <MapPin size={11} /> Detection feed
          </div>
          <div className="relative flex-1 overflow-hidden">
            <div className="marquee-track" style={{ ['--mq' as string]: '55s' }}>
              {[0, 1].map((dup) => (
                <div key={dup} className="flex shrink-0 items-center">
                  {ticker.map((t, i) => (
                    <span key={`${dup}-${i}`} className="flex items-center gap-3 whitespace-nowrap px-6 font-mono text-[10.5px] tracking-[0.14em] text-smoke">
                      <span className="h-1 w-1 rounded-full" style={{ background: t.includes('NRT') ? NRT_COLOR : '#ff6a1f' }} />
                      {t}
                    </span>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
