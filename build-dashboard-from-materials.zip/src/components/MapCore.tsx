import { memo, useMemo } from 'react';
import { MULTAN_BOUNDARY, PLACES } from '../data/boundary';
import type { Fire, Sat } from '../data/fires';

/** Geo domain covering district + fire envelope (full OSM west arm 71.0078+) */
export const DOMAIN = { lon0: 70.98, lon1: 71.90, lat0: 29.36, lat1: 30.465 };
export const MAP_W = 720;
export const MAP_H = 1080;

export const project = (lon: number, lat: number): [number, number] => {
  const x = ((lon - DOMAIN.lon0) / (DOMAIN.lon1 - DOMAIN.lon0)) * MAP_W;
  const y = ((DOMAIN.lat1 - lat) / (DOMAIN.lat1 - DOMAIN.lat0)) * MAP_H;
  return [x, y];
};

export const SAT_COLOR: Record<Sat, string> = { SNPP: '#ffb020', N20: '#ff6a1f', N21: '#ff4d5e' };
export const NRT_COLOR = '#52e5ff';

const boundaryD = (() => {
  let d = '';
  MULTAN_BOUNDARY.forEach(([lon, lat], i) => {
    const [x, y] = project(lon, lat);
    d += `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
  });
  return d + 'Z';
})();

const graticule = (() => {
  const lines: { x1: number; y1: number; x2: number; y2: number; label: string; lx: number; ly: number; vert: boolean }[] = [];
  for (let lon = 71.2; lon <= 71.8; lon += 0.2) {
    const [x] = project(lon, 0);
    lines.push({ x1: x, y1: 0, x2: x, y2: MAP_H, label: `${lon.toFixed(1)}°E`, lx: x + 5, ly: MAP_H - 8, vert: true });
  }
  for (let lat = 29.4; lat <= 30.4; lat += 0.2) {
    const [, y] = project(0, lat);
    lines.push({ x1: 0, y1: y, x2: MAP_W, y2: y, label: `${lat.toFixed(1)}°N`, lx: 8, ly: y - 5, vert: false });
  }
  return lines;
})();

export const MapCanvasDefs = () => (
  <defs>
    <filter id="bGlow" x="-40%" y="-40%" width="180%" height="180%">
      <feGaussianBlur stdDeviation="14" result="b" />
      <feMerge>
        <feMergeNode in="b" />
        <feMergeNode in="SourceGraphic" />
      </feMerge>
    </filter>
    <filter id="fGlow" x="-120%" y="-120%" width="340%" height="340%">
      <feGaussianBlur stdDeviation="2.6" result="b" />
      <feMerge>
        <feMergeNode in="b" />
        <feMergeNode in="SourceGraphic" />
      </feMerge>
    </filter>
    <radialGradient id="fillDist" cx="52%" cy="42%" r="72%">
      <stop offset="0%" stopColor="#ff7a29" stopOpacity="0.055" />
      <stop offset="60%" stopColor="#ff7a29" stopOpacity="0.028" />
      <stop offset="100%" stopColor="#ff7a29" stopOpacity="0.012" />
    </radialGradient>
    <pattern id="hatch" width="7" height="7" patternTransform="rotate(45)" patternUnits="userSpaceOnUse">
      <rect width="7" height="7" fill="transparent" />
      <line x1="0" y1="0" x2="0" y2="7" stroke="#ff6a1f" strokeWidth="1" strokeOpacity="0.35" />
    </pattern>
    <clipPath id="distClip"><path d={boundaryD} /></clipPath>
  </defs>
);

export const Graticule = memo(() => (
  <g aria-hidden>
    {graticule.map((l, i) => (
      <g key={i}>
        <line x1={l.x1} y1={l.y1} x2={l.x2} y2={l.y2} stroke="#ffb05c" strokeOpacity="0.07" strokeDasharray="2 7" />
        <text x={l.lx} y={l.ly} fill="#8b93a1" fillOpacity="0.5" fontSize="10.5" fontFamily="JetBrains Mono, monospace">{l.label}</text>
      </g>
    ))}
  </g>
));

export const Boundary = memo(({ strong = false }: { strong?: boolean }) => (
  <g aria-hidden>
    <path d={boundaryD} fill="url(#fillDist)" stroke="none" />
    <path d={boundaryD} fill="none" stroke="#ff6a1f" strokeOpacity={strong ? 0.28 : 0.16} strokeWidth={strong ? 5 : 3.4} filter="url(#bGlow)" />
    <path d={boundaryD} fill="none" stroke="#ffbf75" strokeOpacity={strong ? 0.9 : 0.6} strokeWidth="1.3" />
  </g>
));

export const PlaceLabels = memo(() => (
  <g aria-hidden>
    {PLACES.map((p) => {
      const [x, y] = project(p.lon, p.lat);
      return (
        <text
          key={p.name}
          x={x}
          y={y}
          textAnchor="middle"
          fill={p.out ? '#69717d' : '#aeb6c2'}
          fillOpacity={p.out ? 0.55 : 0.8}
          fontSize={p.name === 'Multan City' ? 13 : 10.5}
          fontWeight={p.name === 'Multan City' ? 600 : 400}
          fontStyle={p.out ? 'italic' : 'normal'}
          fontFamily="JetBrains Mono, monospace"
          style={{ textTransform: 'uppercase', letterSpacing: '0.14em' }}
        >
          {p.name}
        </text>
      );
    })}
  </g>
));

export function fireRadius(frp: number) {
  return Math.min(9, 2 + Math.sqrt(Math.max(0.4, frp)) * 1.35);
}

interface PtsProps {
  fires: Fire[];
  filter?: (f: Fire, i: number) => boolean;
  dim?: boolean;
  glow?: boolean;
  onHover?: (f: Fire | null) => void;
  animate?: boolean;
}

export const FirePoints = memo(function FirePoints({ fires, filter, dim = false, glow = true, onHover, animate = true }: PtsProps) {
  const list = useMemo(() => (filter ? fires.filter(filter) : fires), [fires, filter]);
  return (
    <g clipPath="url(#distClip)">
      {list.map((f, i) => {
        const [x, y] = project(f.lon, f.lat);
        const nrt = f.src === 'nrt';
        const c = nrt ? NRT_COLOR : SAT_COLOR[f.sat];
        const r = nrt ? 3.4 : fireRadius(f.frp);
        return (
          <g key={i} className={animate ? (nrt ? 'nrt-pt' : 'fire-pt') : undefined} style={animate ? { animationDelay: `${(i * 13) % 400}ms` } : undefined}>
            {(f.frp > 14 || nrt) && <circle cx={x} cy={y} r={r * 2.5} fill={c} opacity={nrt ? 0.22 : 0.13} />}
            <circle
              cx={x} cy={y} r={r}
              fill={c}
              fillOpacity={dim ? 0.4 : 0.92}
              filter={glow ? 'url(#fGlow)' : undefined}
              stroke={nrt ? '#06222b' : '#1a0f06'}
              strokeWidth="0.6"
              style={onHover ? { cursor: 'crosshair' } : undefined}
              onMouseEnter={onHover ? () => onHover(f) : undefined}
              onMouseLeave={onHover ? () => onHover(null) : undefined}
            />
            {nrt && (
              <circle cx={x} cy={y} r={r + 4.5} fill="none" stroke={c} strokeWidth="1" strokeOpacity="0.8" className="pulse-dot" style={{ color: c }} />
            )}
          </g>
        );
      })}
    </g>
  );
});
