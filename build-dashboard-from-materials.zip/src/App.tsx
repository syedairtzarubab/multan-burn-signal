import { useState } from 'react';
import Boot from './components/Boot';
import TopBar from './components/TopBar';
import Hero from './components/Hero';
import Kpis from './components/Kpis';
import SeasonMap from './components/SeasonMap';
import Charts from './components/Charts';
import Hotspots from './components/Hotspots';
import Pipeline from './components/Pipeline';
import Report from './components/Report';
import Footer from './components/Footer';
import { useRevealRoot } from './components/ui';

export default function App() {
  const [booted, setBooted] = useState(false);
  useRevealRoot(booted);

  return (
    <div className="relative min-h-screen bg-ink text-ash antialiased">
      {!booted && <Boot onDone={() => setBooted(true)} />}
      <TopBar />
      <main>
        <Hero />
        <Kpis />
        <SeasonMap />
        <Charts />
        <Hotspots />
        <Pipeline />
        <Report />
      </main>
      <Footer />
    </div>
  );
}
